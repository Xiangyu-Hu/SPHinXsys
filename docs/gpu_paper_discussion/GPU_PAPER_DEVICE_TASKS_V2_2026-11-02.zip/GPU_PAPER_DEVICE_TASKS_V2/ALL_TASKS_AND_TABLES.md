# GPU 论文实验任务总表与设备分发说明（V2）

日期：2026-11-02。本包按最新讨论重新编制，替代此前实验建议中的浮体/主动游鱼候选及接触因子要求。这里只交付开发与运行任务书，没有执行实际编译或远端实验。

## 1. 如何分发

| 文件 | 接收方 | 任务 |
|---|---|---|
| 01_CURSOR_3090TI.md | 3090 Ti 工作站上的 Cursor | 第一优先：公共工具开发、算例适配、本机精度验证、规模/group/工业实验、制作冻结交接包 |
| 02_CURSOR_CPU64.md | 64 核 CPU 服务器上的 Cursor | 接收冻结包，运行同精度正式 CPU 性能基线和线程扫描 |
| 03_CURSOR_OTHER_GPUS.md | 2080S、4090、H20 各设备上的 Cursor | 接收冻结包，运行共同规模的跨 GPU 性能点 |
| 04_DATA_CONTRACT.md | 所有设备 | 统一参数、计时、吞吐率、结果文件和验收口径，必须随各任务书一起发送 |
| 05_CASE_PARAMETER_TABLES.md | 用户与所有执行者 | 每个案例的输入、输出及其比较用途 |
| case_matrix.csv | 用户 | 可用 Excel 打开的实验矩阵 |
| parameter_dictionary.csv | 用户及开发者 | 逐字段用途与采集方式 |
| planned_runs.csv | 调度者 | 按设备展开的计划运行清单，含重复编号与依赖 |
| run_manifest.template.json | 开发者 | 单次运行元数据模板，所有待定字段必须由现场信息填充 |

“3090 Ti 工作站任务”包含该工作站本机 CPU 的精度对照；不依赖 64 核 CPU。第一组没有 CPU 性能门槛，不能因此省略 CPU 精度参考。所有计算卡先打印实际型号，若现场是3090而非3090 Ti，按实际硬件记录，不混名。

可以将整个包发给3090 Ti端先执行；其他设备只执行对应任务书和公共规范。其他端不得自行改物理模型、分辨率、初态或统计窗口。

## 2. 比较用途标记

| 标记 | 目的 |
|---|---|
| V | 物理验证：解析解、文献、实验或COMSOL |
| P | FP32/FP64与CPU/GPU数值差异 |
| R | 分辨率影响：精度、耗时、内存 |
| G | SYCL工作组大小影响 |
| H | 硬件或CPU线程配置比较 |
| B | 分阶段性能、瓶颈 |
| C | 比较条件一致性、可复现性 |

## 3. 最终案例矩阵

| ID | 案例 | 分辨率 | 3090 Ti工作站 | 64核CPU | 2080S/4090/H20各卡 | 主要用途 |
|---|---|---|---|---|---|---|
| A1 | 2D mixed Poiseuille | L1/L2/L3 | 每档CPU64位、CPU32位、GPU32位各1次 | 无需重复 | 无需重复 | V/P/R |
| A2 | 2D oscillating beam | L1/L2/L3 | 同A1；L2选做GPU64位1次 | 无需重复 | 无需重复 | V/P/R |
| A3 | 窗框传热D4优先，D7已有成熟GPU/参考数据则选D7 | L1/L2/L3 | 同A2；D4/D7最终只选一个 | 无需重复 | 无需重复 | V/P/R |
| A4 | 2D two-phase dambreak | L1/L2/L3 | 同A1 | 无需重复 | 无需重复 | V/P/R |
| A5 | 2D cylinder+flexible tail FSI2 | L1/L2/L3 | 同A1 | 无需重复 | 无需重复 | V/P/R |
| B1 | 3D复杂几何单分辨率level-set粒子生成/松弛 | L1—L5 | GPU FP32五档×3次；L3 group 32/64/128/256各×3次 | CPU FP32五档×3次，超预算按任务书降级 | 每卡COMMON档×3次 | R/G/H/B |
| B2 | 3D dambreak | L1—L5 | 同B1 | 同B1 | 同B1 | R/G/H/B |
| B3 | 3D twisting column | L1—L5 | 同B1 | 同B1 | 同B1 | R/G/H/B |
| C1 | 工业齿轮箱 | COMMON一档 | GPU FP32性能窗口×3次；展示轨迹1次 | COMMON FP32×3次 | 每卡COMMON×3次 | H/B/C |
| C2 | 工业搅拌，冻结成熟单相或两相版本 | COMMON一档 | 同C1 | 同C1 | 同C1 | H/B/C |
| C3 | 两相储箱换热+晃荡 | COMMON一档 | 同C1 | 同C1 | 同C1 | H/B/C |

CPU64位/CPU32位指浮点FP64/FP32，不是CPU核心数。64核服务器任务的正式性能基线统一FP32。

COMMON是“同一案例跨硬件共同的冻结规模”，不是所有案例粒子数都相同。B组优先将COMMON设为L3，必须满足最小显存设备的可运行条件；如果不满足，改选五档中的另一档，并在3090 Ti端同步生成配对结果。各设备不得各选自己的COMMON。

工作组主基线暂定64；扫描后若有充分理由改为另一统一设置，必须先冻结并重跑受影响主性能点。其他GPU主表仍采用相同设置；设备专属最优group仅作可选补充。

## 4. 工作量与启动顺序

3090 Ti主计划：A组45条精度轨迹；B组45条规模性能运行；G组36条工作组短窗口；C组9条性能窗口，共135条计划记录，外加2条可选GPU FP64以及工业展示轨迹。若G=64与B组对应点的初态、计时模式、窗口、输出等完全一致，可复用结果，不能重复计为独立样本。短测、失败排查和少量profile不包含在这些数量中。

64核CPU主性能：B组45次+C组9次=54次；线程扫描另列。每个其他GPU：B组三例+C组三例，各3次，共18次；三张卡合计54次。不包括可选大规模展示和短测。计划清单是上限目标，不代表无条件提交所有长任务；先估算CPU和显存成本。

建议顺序：公共采集工具与CPU/GPU短测 → A1/A2/A3粗档，同时适配A4/A5 → B组中档与group试验 → A组三档与B组五档 → C组窗口与冻结包 → CPU64及其他GPU配对。A5若适配暂时卡住，其余合格任务继续，不换成浮体或游鱼。

## 5. 交接与版本约束

3090 Ti端输出一个experiment_bundle，包含版本与本地补丁、源码/依赖说明、输入和初始粒子、必要restart、COMMON映射、五档分辨率表、group策略、物理窗口、计时定义、运行清单、SHA256清单与少量参考结果。若代码来自不同工业分支，为每例记录repo/ref/commit，允许不同case用不同冻结提交，但同case的跨设备必须同版本。

先完成短窗口冻结即可让CPU服务器尽早开始，不必等待全部长程展示结束。冻结之后若物理或计时实现改变，升级experiment_revision并把受影响的全部配对运行标为待重跑。环境适配若改变数值代码，也必须回到3090 Ti端验证。

本包不要求立即发布代码、推送主分支或开启远端任务；它给Cursor明确的本机开发和运行范围。保留用户未提交工作，不清理旧文件、不覆盖输入与历史结果。


---

# 第一部分：3090 Ti工作站 Cursor 开发与运行任务书

## 交给Cursor的目标

先阅读00_START_HERE、04_DATA_CONTRACT、05_CASE_PARAMETER_TABLES。本机负责全部公共开发与先导，完成A组精度、B组五档规模/group、C组三个代表工业窗口，并生成其他设备可直接复用的冻结包。可以使用本机CPU做精度对照，不依赖64核服务器。

授权范围：检查和改造用户指定本地repo、编译、短测、配置记录、按放行队列本机运行；不推送主分支、不改变其他用户工作、不替用户清理未提交文件。先报告真实路径和状态，不假定已有远程权限或引用SSH记忆里的地址。

## T0：盘点与隔离

1. 查看当前工作区、AGENTS、git状态、分支、SHA和依赖。不要reset/clean已有工作；用独立实验分支/worktree或用户现有允许的工作目录。
2. 实际打印GPU名称、可用显存、驱动、SYCL设备/backend，以及CPU/内存。发现3090而非3090Ti如实命名。
3. 查找下表候选；不同本地分支允许路径不同，记录真实来源。仓库历史核查SHA仅作定位参考，不要求回退掉新开发。

| ID | 已核查的主仓库候选路径 | 现场要确认的事 |
|---|---|---|
| A1 | tests/tests_sycl/2d_examples/test_2d_mixed_poiseuille_flow_sycl/mixed_poiseuille_flow.cpp | CK CPU/GPU与解析剖面、分段timer |
| A2 | tests/tests_sycl/2d_examples/test_2d_oscillating_beam_sycl/oscillating_beam.cpp | 与CPU模型/初始激励一致 |
| A3 | tests/2d_examples/test_2d_windows_frame_diffusion_D4/ 或 D7/ | 主仓库已核查传统CPU；本地查GPU实现和COMSOL数据 |
| A4 | tests/tests_sycl/2d_examples/test_2d_two_phase_dambreak_ck/two_phase_dambreak.cpp | 相间模型CPU-CK等价 |
| A5 | tests/2d_examples/test_2d_fsi2/fsi2.cpp | 标准圆柱+柔性尾板；本地查GPU移植，禁止换成浮体 |
| B1 | tests/tests_sycl/3d_examples/test_3d_particle_relaxation_single_resolution_sycl/particle_relaxation_single_resolution_3D.cpp | 替换为成熟复杂几何，检查体填充/薄壳语义 |
| B2 | tests/tests_sycl/3d_examples/test_3d_dambreak_sycl/dambreak.cpp | 动态邻域与实际步数 |
| B3 | tests/tests_sycl/3d_examples/test_3d_twisting_column_sycl/twisting_column.cpp | 参考关系实际是否重建 |
| C1 | 工业齿轮箱：本地冻结分支 | 精确源文件、CPU-CK对照、热模块、旧contact-factor混合区 |
| C2 | 已知程序名线索test_3d_stirring_two_phase_sycl | 单相/两相选择当前成熟版本，不为论文新加物理 |
| C3 | 已知程序名线索test_3d_tank_sloshing_heat_transfer_ck | 热晃荡模型及CPU等价路径 |

历史主仓库核查SHA：1612330e44c8947406f24b6756449e80dcd7158e；SPHinXsim曾带独立内嵌SPHinXsys，不能混用版本。EinSIMO远端访问未核实，优先使用用户本地已有代码。source_inventory.csv逐例列真实repo/ref/SHA/CPU路径/GPU路径/参考数据/状态。

## T1：先完成公共采集与精度构建

1. 建CPU-CK FP32、CPU-CK FP64、GPU FP32三个隔离构建目录；CPU型号不作性能门槛。尽量同一CK源与相同编译优化政策。每次启动打印sizeof(Real)、实际device、group与版本。
2. 之前核查的根CMake在SYCL=ON时强制FLOAT=ON。GPU FP64只是A2/A3中档可选敏感性实验：先检测fp64支持，再在实验分支让精度选项可配置，检查类型/常量/库/原子路径；不盲目把一个开关当作成功。若需要大改或不稳定，写unsupported/deferred，不阻塞GPU FP32主线。
3. 增加实验配置/统一日志、窗口计时、状态检测、资源监测和汇总脚本。沿用现有库接口，避免为计时重写物理算法。
4. 修复Poiseuille缺少分段起点更新等已有timer问题；审查其他案例计时闭合、已有同步、实际结束时间。
5. 去掉齿轮箱contact factor/覆盖率统计的执行和输出，保留真实黏性力；物理必需力/热操作不能删。对比开关前后少量物理轨迹，确认删除的是诊断。
6. 实现preflight：输入hash、参数/单位、精度、时间窗口、body数目、必要输出、group可用性、失败状态。补齐字段再长跑。

交付：支持至少单case、单配置运行的runner；只做计划的dry-run；失败可恢复且不覆盖目录；日志解析/计算误差/汇总表脚本。不要求测试所有仓库模块，只验证本次受影响运行路径。

## T2：A组适配与物理验证

每例三档×CPU FP64/CPU FP32/GPU FP32各1次。粗档短测先检查必要字段真实写出，再完成全轨迹。输出05中全部验证量，以及L2/Linf、振幅/频率/相位、收支等适用指标。参考缺失标为待补，不拿CPU结果冒充独立物理真值。

### A1 Poiseuille

以已核查通道DH/dp=20/40/80为起点。记录Re实际定义、mu、压差、坐标/入口函数及验证剖面位置。开启粒子增删时保存质量收支与N(t)。传统CPU对照若边界/积分不同，不与CPU-CK比较混名。时间长度以达到所选稳态/瞬态比较要求为准。

### A2 梁

厚度方向10/20/40层起点；固定梁几何、激励、本构、阻尼。保存梁端两分量、频率、振幅、能量。小振幅/细长理论不适用时使用合适文献/高精度参考。L2选做GPU FP64，不为此重跑全部精度矩阵。

### A3 窗框

优先D4，若D7已有成熟GPU与完整COMSOL结果则用D7，只选一个。找到参考数据文件/参数来源，记录来源、网格和稳态条件；没有数据不伪造。现有传统CPU的局部导热系数、多材料接口、Robin内外边界、局部减弱换热要等价迁移到CK/GPU。先用已有简化扩散短测检查符号/热流，再跑窗框；Neumann不另扩成主文第六例。

三档dp由窄区/材料厚度可解析性决定，先导后填写resolution_table。稳态以温度残差和内外热流收支判定，不仅凭原源码end_time。若采用热扩散伪时间推进，注明物性与时间量纲，不能把无热容定义的伪时间当真实热响应。

### A4 两相溃坝

dp=0.05/0.025/0.0125可作源码尺寸下的起点，先看CPU/显存成本；固定两相密度比、声速、重力和界面模型。保存压力峰值/时间、界面、前沿、各相质量和机械能。参考实验/文献必须匹配几何和无量纲条件。

### A5 标准FSI2

查本地移植；若无，按CPU fsi2建立CK/SYCL版本。迁移流体、尾板结构积分、固定夹持、压力与黏性双向力、结构法向/平均速度、固体子步和关系更新。不得替换为刚体或主动游鱼。

主仓库传统头文件曾见全局dp=0.1、尾板厚0.2，但固体可另有adaptation；必须统计真实尾板层数，不盲用这个全局默认作为精度档。固定流固dp比，先导选择三档实际可解析尾板厚度。检查已有reload粒子开关与初始文件完整性，所有后端使用同一初态。

子步保护触发、非正dt或不完整推进判失败；核对力传递方向、平均速度时间区间、参考构型关系与接触关系。记录尾端轨迹、稳定周期统计、压力/黏性载荷；对齐采样时刻，不用时间扭曲替代相位对比。

交付：A_case_validation.csv、逐例误差/参考来源与图、三档对照原始数据、待解决项。A5/A3若卡住，其余合格case继续排队；状态写明不能宣称全组已完成。

## T3：B组五档性能与G扫描

1. B1选择用户可公开、复杂但已能稳定生成粒子的单分辨率三维几何；例如已有容器/叶轮/复杂零件。不引入多分辨率粒子算法。几何文件和hash冻结，确保无缺失/错误缩放；不把预设薄壳生成当实体体填充。
2. 三例均先L3中档预热/短窗口，统计N、显存/主存与时间、邻居数量，定L1—L5和共同规模候选。显存预估只作估计，COMMON待最小显存端短测确认。
3. 每例L3扫描group32/64/128/256，各3次。保持同初态、窗口、输出和计时政策；先分析完整求解与阶段时间，不只挑某kernel的最快点。默认64主线；若改统一设置先冻结后重跑。
4. 五档主性能各3次。B1固定1000次松弛可沿用源码起点，另记录到达预定粒子质量阈值的迭代及耗时（若未达到记录未达到）。B2/B3固定物理区间且保存实际各级步数。原默认20s/0.5s不自动成为短窗口要求，先导选代表段后冻结。
5. profile每例只取一个代表规模，必要时加最细档；先保留兼容MPPS/MNIPS，再按真实模块步数给工作量，不虚构相同更新操作。

交付：resolution_table.csv（dp/N/body分解/COMMON映射）；group_sensitivity.csv及图；B_scaling.csv、阶段组成、内存曲线、run_registry与失败日志。

## T4：工业C组三个代表规模

每例固定成熟工况与单一COMMON分辨率，保留全部原有物理求解、关闭专用contact factor/覆盖率诊断。搅拌优先稳定版本；储箱不为本论文新增相变/EM；齿轮箱保留已验证热模型，不能为提速关热后仍称热耦合。

先做小/共同规模短测CPU-CK与GPU核查输出；选性能窗口，足够体现正常移动/界面/热操作，不只计静止启动段。周期运动优先覆盖多个代表周期，具体窗口以先导/预算冻结；记录前窗成本。热长程展示和短性能窗口分开：本机GPU可以完成展示，若过于昂贵保留短展示、把长展示列可选并记录预计成本，不让其阻塞配对包。

每例GPU性能窗口3次，物理展示轨迹1次，可复用同一条轨迹的输出而不重复计算；若没有全程轨迹则不编造。选定帧、restart与最低诊断见05。原gearbox 2.1s是可参考窗口，不自动要求所有新工业case都跑2.1s。

交付：C_common_benchmark.csv、阶段图、最低诊断对照、展示帧、初态/restart及hash、CPU/其他GPU待跑队列。若2080S装不下代表规模，可冻结额外小规模共同点并在3090 Ti配对，不能私改其他卡dp。

## T5：冻结包与验收

冻结包提供所有case源代码/依赖说明或可获取ref及补丁、资产、初始粒子/restart、配置、group和计时政策、完整hash、run清单、构建/运行/解析说明。若工业资产不能对外公开，包仍须供用户授权的设备复用，不擅自公开。

输出README_HARDWARE_HANDOFF，给出一条先preflight/dry-run再单点运行的现场可用命令（只能填已经实现并试过的实际命令），不要在交接里发明不存在的CLI。分发给CPU64和其他GPU时不要求其重做A组或选择参数。

验收清单：
- [ ] 真实device与Real类型可见；A组三档、参考与FP32影响有结果/明确阻塞状态。
- [ ] A5为柔性尾板双向FSI；A3为选定窗框并有独立参考来源。
- [ ] B组三例五档、G扫描、三次性能重复、内存/阶段数据齐全。
- [ ] 工业组三例代表窗口可重跑，必要物理保持、专用统计已删除。
- [ ] 同一case across-device条件可由hash、配置、窗口核对。
- [ ] 计时闭合、失败判定、重复目录、summary解析在短测验证。
- [ ] 冻结包可在一个干净目录复现至少一个短测，不需要手动改物理源码。

最终给用户：已完成/待完成清单、运行数量、主要误差、group结论、资源/时间预算、CPU64与其他GPU交接包路径。没有执行的任务如实写pending，不能用计划参数填结果。


---

# 第二部分：64核CPU服务器 Cursor 任务书

## 目标与前置条件

阅读00、04、05；接收3090 Ti端冻结的experiment_bundle。负责同源FP32正式CPU性能基线，不重新选择物理模型、COMMON、group政策或诊断策略，不重做A组精度。该任务不依赖GPU在本机可用。

包未到可先盘点CPU型号、物理核/逻辑线程、NUMA、内存、编译器及依赖并估算构建准备；物理输入/窗口未冻结前不提交正式长任务。禁止基于旧论文CPU时间与新GPU时间直接计算加速比。

## C64-0 环境与配对检查

1. 保留已有工作，用隔离工作目录/分支接收冻结包；验证源码与资产hash、experiment_revision。每case可能来自不同分支，按source_inventory构建。
2. Release构建CPU-CK FP32，启动打印sizeof(Real)=4和host-parallel后端。GPU精度验证中的CPU FP64不是此处性能基线。
3. 使用同版本编译器与尽量相同优化/fast-math政策；不可避免差异记录到manifest，不能默默替换数值算法。SIMD/本机优化flags也记录。
4. 识别实际64个物理核与SMT/NUMA布局；以拓扑而非连续CPU编号猜测绑核。线程限制须对TBB真实生效并核查，别只设置OMP变量后假定TBB已受控。
5. 测一个B组短窗口和一个工业短窗口，核对输入/粒子数/步数/物理诊断、计时和输出模式，确认与3090 Ti版本一致。

## C64-1 CPU线程敏感性（先于大批长任务）

| 案例 | 规模 | 配置 | 重复 |
|---|---|---|---|
| B2 3D dambreak | 冻结COMMON（预算不足时由协调端另冻结代表档） | 1/8/16/32/64物理核 | 每配置先导1次；正式报告点补至3次 |
| B3 3D twisting column | 同上 | 同上 | 同上 |
| 可选SMT | 与上述同规模 | 64核/128线程，仅实际可用时 | 代表点3次 |

相同配置使用同一NUMA/首次接触政策、无其他大负载。报告CPU基线64物理核，并标出扫描中实际最快配置；如果SMT更快可附SMT结果，但不把128线程叫128核。不得为每个case无记录地挑不同核数。

交付cpu_thread_scaling.csv、拓扑与绑定配置、实际线程数证据、性能曲线及建议。

## C64-2 B组规模配对

| 案例 | 主任务 | 必须记录 |
|---|---|---|
| B1 粒子生成/松弛 | L1—L5，各3次 | 预处理总时间、level-set/生成/松弛等阶段；质量和迭代；内存 |
| B2 3D dambreak | L1—L5，各3次 | 相同物理窗口；各级步数、MPPS/MNIPS估计、邻域/物理阶段、内存 |
| B3 3D twisting column | L1—L5，各3次 | 相同窗口；结构步数、实际关系更新、阶段、内存 |

先共同规模和中粗档，最细档先导估算。若预计明显超出用户可用预算/内存，不私自更改dp或窗口：记录deferred、预计耗时、已完成覆盖；至少完成COMMON及三档可负担规模，保持与GPU有配对。待协调端决定是否新增所有设备统一短窗口。不能用粗档时间线性外推充当最细档实测。

所有正式B结果同一已声明CPU配置；线程扫描单列。无需运行GPU group扫描。

## C64-3 C组三个工业窗口

齿轮箱、搅拌、热晃荡各COMMON档3次。用冻结相同初态/restart与窗口；先验证跨后端恢复支持。若必须从t=0推进，记录前窗和窗口时间，不把GPU恢复运行与CPU完整推进时间直接相除。无需在CPU重复长热展示。

必须启用相同物理模块、运动和热边界。关闭contact factor/覆盖率等专用统计；必要耦合力与热求解不能删除。按固定频率记录最低扭矩/温度/质量诊断和实际步数。

## C64-4 汇总与交付

输出CPU run目录及registry、thread_scaling、B/C summary与计时细目、内存、失败/延期列表。只有匹配run_key（版本/输入/规模/精度/窗口/输出）的结果才计算GPU加速比；不能把CPU线程扫描的最佳单次和GPU三次中位数不加说明比较。

检查group_time_ratio=CPU组内时间之和/GPU组内时间之和；MPPS/MNIPS口径一致；静态墙不冒充全部实际更新粒子。CPU/GPU不同自适应步数如实记录，不强行改步数使加速好看。

最终报告区分本机已测CPU结果和从交接包导入的GPU结果，说明缺失配对、compiler/NUMA差异与潜在影响。无需推送/合并仓库。


---

# 第三部分：2080S、4090、H20 各GPU端 Cursor 任务书

本任务书复制给每个设备，逐台只运行该设备任务。配套00、04、05和3090 Ti冻结包。3090 Ti已经作为主开发设备跑过对应点，不在此重复安排。

## G0：环境与设备选择

核对完整GPU型号、UUID、显存及实际可用量、主机CPU/内存/PCIe、driver、CUDA、oneAPI/Codeplay、OS和依赖。H20记录MIG/共享/功率限制（如适用）；双4090机器明确选择单一UUID，不默认多GPU。每次打印真实device，不能误选CPU backend。

保留用户现有文件，用独立构建与运行目录。从冻结源码/补丁构建GPU FP32，验证sizeof(Real)=4、库版本和数值优化政策。允许不同架构的必要target编译适配，但记录全部flags；不能借此改变物理算法。当前任务不要求FP64、A组精度、五档扫描或重新调group。

## G1：共同规模放行

每例先preflight+短测：确认输入/初始粒子/restart/hash、dp、COMMON、group、窗口、输出与3090 Ti配对一致。检查峰值显存、异常与诊断，保存环境信息。最小显存2080S尽早做初始化/短测，为共同规模确认提供结果，不需要等待所有3090 Ti长任务结束。

OOM不能自行粗化后仍标COMMON。反馈协调端：具体case、N、预留/邻居规模、显存错误、建议候选档。可选择(1)全设备冻结额外小规模公共点并补3090 Ti/CPU；或(2)该卡此点记OOM/NA，其他卡继续原代表规模。两种选择均可，不能在同表将不同dp的时间直接相除。

## G2：每卡正式队列

| ID | 案例 | 分辨率 | 次数 | 记录 |
|---|---|---|---|---|
| B1 | 复杂几何单分辨率粒子生成/松弛 | COMMON | 3 | 预处理/松弛总与阶段时间、迭代质量、显存/主存 |
| B2 | 3D dambreak | COMMON | 3 | 固定窗口总/阶段时间、步数、吞吐率、内存 |
| B3 | 3D twisting column | COMMON | 3 | 同上，固体步数/关系更新 |
| C1 | 齿轮箱 | COMMON | 3 | 固定工业窗口，含全部冻结流热模块、最低诊断 |
| C2 | 搅拌 | COMMON | 3 | 冻结单/两相与桨叶运动；最低诊断 |
| C3 | 两相储箱换热晃荡 | COMMON | 3 | 冻结两相/热/运动模型；最低诊断 |

每卡18次性能运行；不包括短测与可选profile。各卡主表统一group政策（起点64），不能私自调成各卡最优而不标明。三次同一初态/窗口，避免同时占用GPU、共享host或热降频导致的干扰；出现异常保留失败日志。

详细profile每卡最多选一个B和一个C代表点先做，若已有低开销同口径阶段计时则直接使用；无需所有点逐kernel强制同步。group专项已在3090 Ti完成；如需研究可移植性，另建补充队列，不塞进主计划。

## G3：4090/H20可选增强，不阻塞主线

在共同规模配对全部完成后，可选C1或C3增加一个细档/更大规模，展示单卡容量与实际可运行性；也可接管昂贵长物理展示。必须记录新增dp/N、显存、物理条件和时间，作为容量展示单列；没有相同规模CPU/其他GPU配对时，不宣称相应跨设备加速比。

H20部署若不成熟，先报告具体编译/设备阻塞，其他卡继续。不能以型号推测结果或用峰值算力替代实测；禁止声称多GPU扩展性。

## G4：交付与合并

每卡输出run_manifest/physics、summary/stages/steps/body_stats/telemetry、最低诊断、环境、退出状态与run_registry，保持冻结run_key。汇总表一行一运行，结果合并脚本按硬件label和rep生成median/min/max，而不覆盖3090 Ti基准。

不同GPU在不同host上的结果标为系统级比较；表中必须列host。跨GPU速度比只对相同输入/规模/精度/窗口/输出/group政策计算。未支持、OOM和延期保留NA/原因。

最终向用户报告：该设备完成18次中的多少次、哪些case异常、相对3090 Ti/CPU的匹配结果（有数据才算）、host/软件差异、可选大规模点状态。无需重复A组、公开工业资产或推送主分支。


---

# 公共数据与计时规范

所有三份设备任务书依赖本文件。比较用途V/P/R/G/H/B/C见总表。

## 1. 运行配置与模式

每个case用显式配置控制：spacing_id及dp、后端、精度、device、work_group_size、物理结束时间/窗口、输出时刻/字段、随机种子/初始粒子文件、重复编号、排序/关系更新周期、线程/绑核。实际CLI或JSON接口由Cursor基于现有代码选择，但不能只改源码常量而不保存最终值；新增选项在help中说明并校验。

模式至少四种：validate（完整物理数据）；benchmark（最少必要诊断、主性能）；profile（少量代表窗口、详细分段）；showcase（展示帧和restart）。若分段计时可在不改变正常执行顺序且开销足够小时直接收集，可用于benchmark；否则单独profile并标注开销。不要把同步插桩profile时间混进主加速比。

## 2. 输入与运行信息：必须字段

| 字段 | 内容 | 比较 |
|---|---|---|
| experiment_revision,run_id,case_id,mode,rep | 唯一运行身份与目的 | C |
| repo,commit,dirty_patch_hash,binary_hash | 源码和二进制；补丁实际归档 | C |
| input_hash,initial_particles_hash,restart_hash | 输入、初态与重启一致性 | P/R/G/H/C |
| backend,real_bytes,precision_policy | CPU-CK/GPU/legacy、sizeof(Real)、是否混合精度 | P/H/C |
| compiler,flags,cmake,dependency_versions | Release、优化/fast-math、oneAPI/Codeplay/CUDA/driver/oneDPL/TBB等 | P/H/C |
| device_model,uuid,host_cpu,ram,pcie,os | 实际完整硬件/系统 | H |
| cpu_physical_cores,threads,affinity,numa,smt | CPU执行与资源限制 | H/C |
| gpu_memory,power_limit,clocks,mig,shared_status | 实际可用显存与设备配置；不适用NA | H/C |
| geometry,units,physics,initial_conditions,boundaries | 每例物理参数与单位、几何坐标/缩放 | V/P/R/H/C |
| dp_by_body,h_over_dp,kernel,corrections | 各body分辨率、核与修正 | V/P/R/C |
| body_active_counts,reserve_capacity,neighbor_counts | 分body工作量、预留、inner/contact邻域统计 | R/H/C |
| dt_rules,cfl,sort_policy,relation_policy | 时间离散与基础设施调用规则 | R/G/H/C |
| requested_group,effective_group,limits | 实际local size；库算子覆盖范围 | G/H/C |
| t_start,t_end,actual_t_end,window,output_schedule | 物理端点与I/O策略 | P/R/G/H/C |

未测字段写null/NA并注明原因，不能以0充当未测；必要字段未填则preflight不通过。

## 3. 原始结果文件

每run独立目录，不能覆盖；退出失败也保留记录。

```text
run_manifest.json / physics.json / environment.txt
stdout.log / stderr.log / exit_status.json
run_summary.csv / stage_timing.csv / step_stats.csv
body_stats.csv / diagnostics.csv / probes.csv / telemetry.csv
snapshots/ / restart/
```

- run_summary：窗口物理跨度、实际各级步数、初始化/求解/输出/restart/验证/进程总时间、峰值内存、状态。
- stage_timing：stage、scope、calls、inclusive_or_exclusive、wall_s、device_event_s（未测NA）、timing_method。图表使用互斥阶段，嵌套inclusive阶段不能相加。
- step_stats：outer/acoustic/solid/diffusion或relaxation迭代计数，dt范围/均值与限制来源，排序/关系更新数。块汇总即可，不必每步写盘。
- body_stats：初始/最小/最大活跃数、预留容量、采样时刻inner/contact有向邻接数量、occupied cells/桶占用（若可测）。高开销统计单独采样，不每步回传GPU。
- diagnostics/probes：按预定物理时刻采样，包含单位、body/phase/测点坐标，具体量见参数表。
- telemetry：约1s采样显存、功率、温度、频率、利用率及可取得的降频信息；用外部低开销采集，记录采样周期。CPU记录RSS和资源占用。

## 4. 计时边界

主指标wall_solver：固定物理窗口内整个求解循环时间，含必要host工作、设备工作/等待、邻域/排序和耦合。所有后端采取同样诊断/I/O政策。若排除I/O，输出边界必须确认设备完成并单独计时，不能把前面积压的设备工作错误归到I/O。另保留solver_window_inclusive，方便核查。

wall_process：进程启动至退出，包含初始化、首次设备工作、I/O和结束检查；不包含编译、人工排队。窗口前warmup可以单独报告，但不丢弃cold-start成本；从初值到窗口的推进不能在物理意义上跳过。

GPU在计时起点前和终点后等待对应设备任务完成并捕获异常。先审查现有wait路径：已核查的particle_for/reduce路径本身含wait_and_throw，不能假定所有调用都异步，也不要再为测量无意义地添加重复等待。其他路径仍逐项确认。主benchmark不为细分强制引入额外逐kernel同步；profile若这么做，明确标记为同步分段诊断。event时间仅在queue支持profiling且覆盖全部相关工作时使用，事件之和不等于墙钟。

互斥阶段建议：geometry、levelset、particle_generation/load、initial_relation；solver内cell_list、sort_scan、relation_inner、relation_contact、fluid_setup/density、pressure_density、viscous/transport/correction、solid_integration/constraint、thermal_diffusion、thermal_source、thermal_boundary、coupling/moving_body、dt_reduce、diagnostics、other；output和restart另列。实际融合算子不能虚构拆分，记录真实分组并说明覆盖内容；分组方式跨设备一致。

禁止统计接触因子或润滑覆盖率。老contact-factor计时区里真正的黏性流固作用必须保留、单列；不能把整段删掉，也不从旧时间估算扣除。力/扭矩若用于耦合是必要物理；仅用于核查时降低采样频率并列入诊断。

检查互斥阶段之和与同口径solver时间闭合，保留other与误差；起步以相对差5%作插桩排错提示，不作为通用数值精度标准。插桩开销需在一个代表窗口对比开关两种模式，不能认定微小分段时间天然准确。

## 5. 吞吐率、加速比与精度指标

主加速比S=T_CPU_FP32/T_GPU_FP32，必须相同case、输入、规模、窗口、数值算法和输出策略。CPU-CK优先；legacy CPU若算子不同单独标注，不混称纯后端加速。

保留齿轮箱论文式的兼容指标：MPPS_proxy=N_total*N_timed_step/(1e6*Twall)，MNIPS_est=N_est_inner_contact*N_timed_step/(1e6*Twall)。元数据必须说明timed_step是哪一级、N_total是否含静态墙、邻居统计是有向还是无向、仅油相还是全部相；MNIPS是估计工作量而非GPU指令数。

动态N时采用逐步或块内累计的sum(N_k)，不能用最终N乘总步数。不同物理模块有不同子步时分别报告fluid/solid/diffusion/relaxation更新工作量，不把它们当作相同的一种更新。额外遍历邻居做统计的成本不能混进主benchmark；估计采样频率、变动范围也记录。无法可信估算MNIPS的case可以NA并说明，不构造虚假可比指标。

另报告wall_per_physical_second=Twall/(t_b-t_a)、各类mean_step_wall、阶段占比、阶段加速、峰值内存、三次重复中位数及min/max。group加速基于同一规模相对基线group计算。solver组加速用CPU组内时间之和/GPU组内时间之和，不平均各kernel加速比。

A组：分别计算CPU FP64/CPU FP32/GPU FP32对独立参考的误差，以及三者相互差。CPU FP64不是物理真值。固定测点/公共采样网格或持久ID比较，排序后数组下标不当粒子身份；不同dt对齐公共物理时刻，不用DTW掩盖相位差。小量附近避免不稳定相对误差，预定归一尺度。

A组平滑场CPU/GPU差1%左右、频率差1%、幅值差数个百分点可作为先导排查目标，但不是已达到结论；最终按参考来源、离散误差及用途在正式跑前冻结容差。冲击/界面长期不要求逐粒子相等；保存峰值/到达时间/窗口统计及收支。

## 6. 五档分辨率与group规则

A组只改dp，保持物理几何、边界和模型不变；FSI流固分辨率比固定。B组L1—L5由粗到细，每档记录实际N，不能只写“百万粒子”。先导定标可用三维体填充相邻dp约1.3—1.5倍作为起点；壳层/边界带不按N~dp^-3盲推。几何过细特征在最粗档也应可解析，否则另选几何或起点。

G扫描只在3090 Ti、每B例一档（优先L3）；32/64/128/256，512为可选。先创建queue再设置group并打印生效值，避免首次queue初始化覆盖设置。校验设备和具体kernel上限、非零local size、global padding与边界保护、规约/屏障正确性；保留默认64作为起点。oneDPL内部操作不一定受该setter控制，如实记录。

主跨设备结果统一group政策，不允许各卡默默挑最快值。若选设备专属调优，单列补充实验。group改变可能改变归约顺序，必须核查诊断结果；非法点记录unsupported，不退回默认后冒充指定group。

## 7. 重复、预算、失败

三次性能重复使用同一初态/窗口，计时模式一致；它们是运行时间重复，不是三个独立物理统计样本。不得对同一GPU同时启动多个性能任务，也不得让本机CPU对照占满GPU求解所需host资源。先导时长不足则延长窗口（一次冻结后所有端一致），昂贵case无需为追求固定墙钟秒数盲目延长。

checkpoint需保留两相、热、固体/刚体、历史量、ID和积分状态，验证恢复连续性及跨CPU/GPU可移植；不通过则所有端从相同初态推进，分别记录prewindow成本和窗口成本。

任何改变物理/步进/计时范围的修复升级版本，旧结果不能混配。失败不自动调dp/group/声速/CFL后继续记在原run_id；每次重试新attempt_id。显存不足写OOM，超预算写deferred，不把NA当0。


---

# 每个案例的参数、输出、比较用途总表

V物理验证；P精度；R分辨率；G工作组；H硬件；B阶段瓶颈；C条件一致。以下每行“输入”都要记录实际值、单位和来源，不能只抄字段名。“输出”要在粗档短测中确认真实生成。所有case还需04里的公共元数据。

## 1. A组：物理与精度验证

| 案例 | 要记录的输入 | 要记录的输出 | 对应比较 |
|---|---|---|---|
| A1 Poiseuille | 通道长高、dp/h、rho/mu/c、Re定义、入口速度及启动函数、出口压力、初态、边界/修正、dt/CFL、探针坐标 | u(y)、中心u(t)、Q(t)、压降、进出口累计质量、N(t)、实际步数/时间 | 解析剖面与流量V；CPU64/CPU32/GPU32差P；三档误差R；收支/步数C |
| A2 梁振动 | 梁长厚、夹持段、dp/厚度层数、rho/E/nu、本构、初始速度/位移激励、阻尼、dt、探针位置 | 尾端x/y位移和速度、主频、各周期振幅、均值/相位、动能/应变能、实际步数 | 文献/适用理论V；精度P；三档R；能量/步数C |
| A3 窗框D4/D7 | 几何/材料区、各区导热系数、rho*cp或扩散/伪时间定义、室内外温度与Robin系数、局部减弱换热区、初温、dp/h、稳态阈值、COMSOL对应配置与测点 | Phi/温度测点、同截面分布、内外总热流、热收支、稳态残差、扩散迭代数与时间 | 对COMSOL V；CPU64/CPU32/GPU32及可选GPU64 P；材料界面细化R；收敛/迭代C |
| A4 两相溃坝 | 水槽/水柱几何、两相rho/mu/c/EOS、重力、相间模型、表面张力/接触角（如启用）、dp/h、CFL、压力探针及界面采样方式 | 界面帧、水位/前沿、压力p(t)/峰值/到达时间、两相质量、最大速度/密度偏差、机械能、步数 | 文献/实验V；精度P；界面/压力细化R；守恒与步数C |
| A5 圆柱柔性尾板FSI2 | 通道/圆柱/尾板尺寸、流固各dp及比值、实际尾板层数、流体rho/mu/c/Re与入口启动、固体rho/E/nu/本构、夹持、阻尼、流固耦合/子步规则、reload初态 | 尾端x/y位移、均值/振幅/频率/相位、结构载荷（压力/黏性）、代表变形/流场、dt/Dt/dt_s、各类步数与保护触发 | 标准FSI文献V；精度P；流固同比细化R；双向传力/子步C |

A组三版本必须共享模型和初态；GPU64仅A2/A3中档可选。不同编译精度可能导致生成粒子差异，优先离线生成一次并统一载入。保存完整验证数据即可，不要求全套性能细分。

## 2. B组：五档规模、group和硬件

| 案例 | 固定物理/算法输入 | 每档规模参数 | 性能字段 | 质量/一致性输出 | 比较 |
|---|---|---|---|---|---|
| B1 复杂几何level-set/松弛 | 几何hash/坐标/缩放、实体/壳层定义、单分辨率设置、SDF网格/修正、随机种子/初始点、松弛规则与停止标准 | L1—L5的dp、实际N、表面N、level-set节点/块/网格层信息、内存 | 几何/level-set/粒子生成/初始关系/松弛/约束时间；迭代均时、粒子更新率、可信邻居估计率、峰值内存 | 表面距离误差、最近邻分布、松弛残差；固定迭代与达到同质量的迭代/耗时 | 五档R；中档group G；COMMON H；阶段B；质量C |
| B2 3D溃坝 | 水槽/水柱、rho/g/c、核/修正、dt/CFL、排序/关系周期、物理窗口 | 每档dp、流体/壁各N、inner/contact邻居统计、occupied cells/桶占用、reserve | solver/process/init/output时间、各级步均时、MPPS/MNIPS口径、cell/relation/sort/流体/规约阶段、峰值内存 | 质量、压力/水位摘要、最大速度/密度偏差、各级步数及实际终止时间 | R/G/H/B/C |
| B3 3D扭转柱 | 柱几何、rho/E/nu/本构、初始角速度分布、固定区、阻尼、dt/约束、物理窗口 | 每档dp、实际固体N、初始参考邻域数、实际重建次数 | solver/init/output时间、结构步均时、结构更新率、relation/固体积分/阻尼/规约/约束、内存 | 端部运动、能量、代表变形、结构步数、失败状态 | R/G/H/B/C |

P1旧编号本包统一为B1；旧表3D dambreak B1本包改为B2，扭转柱改为B3。脚本与CSV统一使用本包编号，禁止按旧ID混配。

## 3. C组：单一代表规模跨设备

| 案例 | 固定并归档的输入 | 性能重点 | 最低物理诊断（低频） | 不列为任务 |
|---|---|---|---|---|
| C1 齿轮箱 | CAD/粒子hash、每body dp、油量/液位、油rho/mu/c/k/cp、固体热物性、各轴omega/运动、初温、热源/边界、物理窗口 | 总/各级步均时、MPPS/MNIPS估计、基础设施/流体/黏性/热扩散/热源/热边界/运动/必要规约、内存 | 各轴扭矩及功率可由omega计算、油温及齿轮/壁温摘要、油质量、步数；热收支仅保留现有低成本量 | contact factor、覆盖率、齿轮表面分区润湿、完整多工况贡献率研究 |
| C2 搅拌 | 容器/桨叶、成熟单/两相选择、液位、各相物性、omega与启动函数、旋转轴/单位、各body dp、运动/邻域规则、窗口 | 总/阶段时间、吞吐率、移动边界/相间接触、内存、实际步数 | 桨叶扭矩、少量速度探针、各相质量；现有自由面/气含率可选 | 新增示踪剂/混合时间研究、为论文临时升级多相 |
| C3 热晃荡储箱 | 储箱/充液率、两相rho/mu/c/k/cp/EOS、相间热模型、初温、壁/环境热边界、晃荡幅频/方向/完整函数、dp、窗口 | 两相/邻域/排序/热交换扩散/运动/规约、总体与吞吐率、内存 | 少量压力/水位探针、两相平均温度、两相质量、实际步数；现成低成本热量摘要 | 新加相变或EM、完整参数扫频研究 |

三例COMMON一档，跨CPU/GPU完全一致；热模型启用的项必须真正计算。最低诊断用于H/B结果的C核查，不扩成新物理验证章节。力/扭矩若驱动物体运动必须按物理需要计算，不能低频化必要耦合；低频化仅指输出/额外诊断。

## 4. 分辨率与比较对象落地表（由先导填写）

| 案例 | 起点建议 | 正式冻结时必须填写 | 用途 |
|---|---|---|---|
| A1 | DH/dp=20/40/80 | dp、各body N、参考剖面位置/终止判据 | V/P/R |
| A2 | 厚度方向10/20/40层 | 实际层数、dp、固体N、激励/观测周期 | V/P/R |
| A3 | 由最窄材料区确定，不猜数值 | 每档dp、可解析厚度、材料分区N、稳态标准 | V/P/R |
| A4 | 源码尺寸下dp=0.05/0.025/0.0125为起点 | dp、各相/壁N、参考与窗口、CPU成本 | V/P/R |
| A5 | 保持流固dp比、足够尾板层数 | 各body dp/N、真实尾板层数、参考条件 | V/P/R |
| B1/B2/B3 | 初始化定标五档；COMMON优先L3 | 每档dp/N/邻域/显存；共同档ID；窗口 | R/G/H/B |
| C1/C2/C3 | 采用成熟有依据的代表dp | 每body dp/N、共同档、初态/restart、窗口 | H/B/C |

不要求各case粒子数相同。每档细化保持物理几何不变；壳层厚度若随dp变化，明确这是算法边界带而非真实结构几何改变，并避免拿此变化作物理收敛结论。

## 5. 结果表模板

### 精度表
case / spacing / dp_by_body / N_by_body / backend / real_bytes / reference / reference_error_L2 / reference_error_Linf / CPU64_difference / frequency_error / amplitude_error / phase_or_arrival_error / mass_or_heat_balance / status。按case填适用字段，NA必须有理由。

### 总体性能表
case / spacing / dp / N_by_body / platform / host / cores_threads / real_bytes / group / physical_window或relax_iterations / steps_by_level / wall_solver / wall_init / wall_process / mean_step_by_level / MPPS_proxy或module_updates / MNIPS_est / peak_VRAM / peak_RSS / speedup / repetitions_range / status。

### 阶段性能表
case / spacing / platform / stage / calls / wall_s / fraction / matching_CPU_stage_s / speedup / timing_mode。分组和细项分别出表，避免父子重复相加。

### group表
case / spacing / effective_group / wall_solver_median / min / max / phase_times / correctness_difference / support_status / library_scope。默认64和调优结果不能混为同一种跨设备基线。

### 发布前检查
所有表能追溯到run_id和原始文件；不录入估算伪装成实测；没跑完明确pending；旧论文归一化到2.1s的数据不与新版本直接混用。图表只呈现完成的匹配数据，设备不足不外推。
