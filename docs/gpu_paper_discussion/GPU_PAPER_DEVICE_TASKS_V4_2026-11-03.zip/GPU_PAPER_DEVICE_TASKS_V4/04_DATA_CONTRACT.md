> V3（2026-11-03）：主协调端为4090＋64核CPU同一服务器。记录细则以06、07为准；旧文档与之冲突时采用06、07。所有结果仍待现场实测。

# 公共数据与计时规范

所有三份设备任务书依赖本文件。比较用途V/P/R/G/H/B/C见总表。

## 1. 运行配置与模式

每个case用显式配置控制：spacing_id及dp、后端、精度、device、work_group_size、物理结束时间/窗口、输出时刻/字段、随机种子/初始粒子文件、重复编号、排序/关系更新周期、线程/绑核。实际CLI或JSON接口由Cursor基于现有代码选择，但不能只改源码常量而不保存最终值；新增选项在help中说明并校验。

模式至少四种：validate（完整物理数据）；benchmark（最少必要诊断、主性能）；profile（少量代表窗口、详细分段）；showcase（展示帧和restart）。若分段计时可在不改变正常执行顺序且开销足够小时直接收集，可用于benchmark；否则单独profile并标注开销。不要把同步插桩profile时间混进主加速比。

## 2. 输入与运行信息：必须字段

| 字段 | 内容 | 比较 |
|---|---|---|
| experiment_revision,run_id,case_id,mode,rep | 唯一运行身份与目的 | C |
| repo,commit,dirty_patch_hash,binary_hash | 源码和二进制；补丁实际归档 | C |
| input_hash,initial_particles_hash,restart_hash | 输入、初态与重启一致性 | P/R/G/H/C |
| backend,real_bytes,precision_policy | CPU-CK/GPU/legacy、sizeof(Real)、是否混合精度 | P/H/C |
| compiler,flags,cmake,dependency_versions | Release、优化/fast-math、oneAPI/Codeplay/CUDA/driver/oneDPL/TBB等 | P/H/C |
| device_model,uuid,host_cpu,ram,pcie,os | 实际完整硬件/系统 | H |
| cpu_physical_cores,threads,affinity,numa,smt | CPU执行与资源限制 | H/C |
| gpu_memory,power_limit,clocks,mig,shared_status | 实际可用显存与设备配置；不适用NA | H/C |
| geometry,units,physics,initial_conditions,boundaries | 每例物理参数与单位、几何坐标/缩放 | V/P/R/H/C |
| dp_by_body,h_over_dp,kernel,corrections | 各body分辨率、核与修正 | V/P/R/C |
| body_active_counts,reserve_capacity,neighbor_counts | 分body工作量、预留、inner/contact邻域统计 | R/H/C |
| dt_rules,cfl,sort_policy,relation_policy | 时间离散与基础设施调用规则 | R/G/H/C |
| requested_group,effective_group,limits | 实际local size；库算子覆盖范围 | G/H/C |
| t_start,t_end,actual_t_end,window,output_schedule | 物理端点与I/O策略 | P/R/G/H/C |

未测字段写null/NA并注明原因，不能以0充当未测；必要字段未填则preflight不通过。

## 3. 原始结果文件

每run独立目录，不能覆盖；退出失败也保留记录。

```text
run_manifest.json / physics.json / environment.txt
stdout.log / stderr.log / exit_status.json
run_summary.csv / stage_timing.csv / step_stats.csv
body_stats.csv / diagnostics.csv / probes.csv / telemetry.csv
snapshots/ / restart/
```

- run_summary：窗口物理跨度、实际各级步数、初始化/求解/输出/restart/验证/进程总时间、峰值内存、状态。
- stage_timing：stage、scope、calls、inclusive_or_exclusive、wall_s、device_event_s（未测NA）、timing_method。图表使用互斥阶段，嵌套inclusive阶段不能相加。
- step_stats：outer/acoustic/solid/diffusion或relaxation迭代计数，dt范围/均值与限制来源，排序/关系更新数。块汇总即可，不必每步写盘。
- body_stats：初始/最小/最大活跃数、预留容量、采样时刻inner/contact有向邻接数量、occupied cells/桶占用（若可测）。高开销统计单独采样，不每步回传GPU。
- diagnostics/probes：按预定物理时刻采样，包含单位、body/phase/测点坐标，具体量见参数表。
- telemetry：约1s采样显存、功率、温度、频率、利用率及可取得的降频信息；用外部低开销采集，记录采样周期。CPU记录RSS和资源占用。

## 4. 计时边界

主指标wall_solver：固定物理窗口内整个求解循环时间，含必要host工作、设备工作/等待、邻域/排序和耦合。所有后端采取同样诊断/I/O政策。若排除I/O，输出边界必须确认设备完成并单独计时，不能把前面积压的设备工作错误归到I/O。另保留solver_window_inclusive，方便核查。

wall_process：进程启动至退出，包含初始化、首次设备工作、I/O和结束检查；不包含编译、人工排队。窗口前warmup可以单独报告，但不丢弃cold-start成本；从初值到窗口的推进不能在物理意义上跳过。

GPU在计时起点前和终点后等待对应设备任务完成并捕获异常。先审查现有wait路径：已核查的particle_for/reduce路径本身含wait_and_throw，不能假定所有调用都异步，也不要再为测量无意义地添加重复等待。其他路径仍逐项确认。主benchmark不为细分强制引入额外逐kernel同步；profile若这么做，明确标记为同步分段诊断。event时间仅在queue支持profiling且覆盖全部相关工作时使用，事件之和不等于墙钟。

互斥阶段建议：geometry、levelset、particle_generation/load、initial_relation；solver内cell_list、sort_scan、relation_inner、relation_contact、fluid_setup/density、pressure_density、viscous/transport/correction、solid_integration/constraint、thermal_diffusion、thermal_source、thermal_boundary、coupling/moving_body、dt_reduce、diagnostics、other；output和restart另列。实际融合算子不能虚构拆分，记录真实分组并说明覆盖内容；分组方式跨设备一致。

禁止统计接触因子或润滑覆盖率。老contact-factor计时区里真正的黏性流固作用必须保留、单列；不能把整段删掉，也不从旧时间估算扣除。力/扭矩若用于耦合是必要物理；仅用于核查时降低采样频率并列入诊断。

检查互斥阶段之和与同口径solver时间闭合，保留other与误差；起步以相对差5%作插桩排错提示，不作为通用数值精度标准。插桩开销需在一个代表窗口对比开关两种模式，不能认定微小分段时间天然准确。

## 5. 吞吐率、加速比与精度指标

主加速比S=T_CPU_FP32/T_GPU_FP32，必须相同case、输入、规模、窗口、数值算法和输出策略。CPU-CK优先；legacy CPU若算子不同单独标注，不混称纯后端加速。

保留齿轮箱论文式的兼容指标：MPPS_proxy=N_total*N_timed_step/(1e6*Twall)，MNIPS_est=N_est_inner_contact*N_timed_step/(1e6*Twall)。元数据必须说明timed_step是哪一级、N_total是否含静态墙、邻居统计是有向还是无向、仅油相还是全部相；MNIPS是估计工作量而非GPU指令数。

动态N时采用逐步或块内累计的sum(N_k)，不能用最终N乘总步数。不同物理模块有不同子步时分别报告fluid/solid/diffusion/relaxation更新工作量，不把它们当作相同的一种更新。额外遍历邻居做统计的成本不能混进主benchmark；估计采样频率、变动范围也记录。无法可信估算MNIPS的case可以NA并说明，不构造虚假可比指标。

另报告wall_per_physical_second=Twall/(t_b-t_a)、各类mean_step_wall、阶段占比、阶段加速、峰值内存、三次重复中位数及min/max。group加速基于同一规模相对基线group计算。solver组加速用CPU组内时间之和/GPU组内时间之和，不平均各kernel加速比。

A组：分别计算CPU FP64/CPU FP32/GPU FP32对独立参考的误差，以及三者相互差。CPU FP64不是物理真值。固定测点/公共采样网格或持久ID比较，排序后数组下标不当粒子身份；不同dt对齐公共物理时刻，不用DTW掩盖相位差。小量附近避免不稳定相对误差，预定归一尺度。

A组平滑场CPU/GPU差1%左右、频率差1%、幅值差数个百分点可作为先导排查目标，但不是已达到结论；最终按参考来源、离散误差及用途在正式跑前冻结容差。冲击/界面长期不要求逐粒子相等；保存峰值/到达时间/窗口统计及收支。

## 6. 五档分辨率与group规则

A组只改dp，保持物理几何、边界和模型不变；FSI流固分辨率比固定。B组L1—L5由粗到细，每档记录实际N，不能只写“百万粒子”。先导定标可用三维体填充相邻dp约1.3—1.5倍作为起点；壳层/边界带不按N~dp^-3盲推。几何过细特征在最粗档也应可解析，否则另选几何或起点。

G扫描只在4090、每B例一档（优先L3）；32/64/128/256，512为可选。先创建queue再设置group并打印生效值，避免首次queue初始化覆盖设置。校验设备和具体kernel上限、非零local size、global padding与边界保护、规约/屏障正确性；保留默认64作为起点。oneDPL内部操作不一定受该setter控制，如实记录。

主跨设备结果统一group政策，不允许各卡默默挑最快值。若选设备专属调优，单列补充实验。group改变可能改变归约顺序，必须核查诊断结果；非法点记录unsupported，不退回默认后冒充指定group。

## 7. 重复、预算、失败

三次性能重复使用同一初态/窗口，计时模式一致；它们是运行时间重复，不是三个独立物理统计样本。不得对同一GPU同时启动多个性能任务，也不得让本机CPU对照占满GPU求解所需host资源。先导时长不足则延长窗口（一次冻结后所有端一致），昂贵case无需为追求固定墙钟秒数盲目延长。

checkpoint需保留两相、热、固体/刚体、历史量、ID和积分状态，验证恢复连续性及跨CPU/GPU可移植；不通过则所有端从相同初态推进，分别记录prewindow成本和窗口成本。

任何改变物理/步进/计时范围的修复升级版本，旧结果不能混配。失败不自动调dp/group/声速/CFL后继续记在原run_id；每次重试新attempt_id。显存不足写OOM，超预算写deferred，不把NA当0。
