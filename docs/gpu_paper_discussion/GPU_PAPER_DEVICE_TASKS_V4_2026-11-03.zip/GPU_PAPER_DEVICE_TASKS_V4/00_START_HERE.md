# GPU论文任务与逐例采集方案 V4

日期：2026-11-03。基于V3补齐本轮的逐case输出与执行配置；当前是任务与模板，没有替用户运行远程物理计算。

**先发给4090端Cursor：11_EACH_CASE_EXECUTION_AND_OUTPUT.md、12_EXACT_SAMPLING_RULES.md及case_cards/对应案例。** 然后接上10、06的公共采集实现。11/12及case卡覆盖旧文档频率/代表配置冲突。

## 新增

- 11张逐case卡：计算内容、输入、必收物理量、性能量、采样规则、VTP字段、终点和验收。
- case_execution_matrix.csv：每种配置的设备/分辨率/精度/重复/曲线/场输出。
- case_output_schedule.csv及output_schedule.csv：逐例输出矩阵。
- tools/freeze_output_schedule.py：用真实T/P/事件窗口等生成绝对时间/迭代列表，仅做配置绑定，不假定求解器已有此接口。
- schedules/*.input.template.json：逐case绑定输入，所有待定物理值为null，不能直接正式运行。
- planned_runs.csv由258条变261条，增加B1/B2/B3各1条代表showcase；C组3条展示已有。A组代表GPU FP32 L2验证直接保存VTP，无额外A展示轨迹。

## 已保留的V3内容

282字段（原174＋108新增）、20类记录、19种CSV模板、元数据JSON、虚构填表示例、文献来源和计时规范。主端4090＋64核CPU；其他已有GPU共同规模配对；不新增跨厂商/跨软件/多GPU实验。

## 一次提交与重复

A组每种精度/分辨率计算一次完整验证。B/C每配置一次提交，由runner完成3次正式性能重复，并仅在指定代表配置加一条展示（可复用已有合格场数据）。不是要求每个配置都多跑展示，也不能承诺一条有VTP轨迹等同3次无输出性能重复。profile和计时开关另为少量代表短窗。

绝对秒数、稳态/振动起点和性能窗口必须现场用已有结果或短先导冻结；本包给确定的采样公式和点数，不编造所有case相同End_Time。输出时间不自动改变求解器时间步。
