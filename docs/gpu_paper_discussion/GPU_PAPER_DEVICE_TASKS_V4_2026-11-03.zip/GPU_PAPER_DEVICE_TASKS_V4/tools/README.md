# 绑定输出时刻

先复制对应schedules模板，填入现场已冻结的真实物理值。示例命令（只生成配置，不执行SPHinXsys）：

```bash
python3 tools/freeze_output_schedule.py schedules/A2.input.frozen.json schedules/A2.output.frozen.json
```

输入文件需由现场创建，输出路径必须尚不存在。模板null会被拒绝。A3伪时间/迭代模式改coordinate=iteration、probe_policy=iterations100并填iterations；时间单位需写manifest。B3若不定义周期，field_policy改evolution8并填field_start/field_end；不要编造P。工业展示如无有效参考周期，曲线改uniform100、场改evolution8，明确是非周期状态。

benchmark使用window51（B1 iterations100），field_enabled=false。A2/A5等cycles100要求E（如填写）等于S+4P_ref；T为该轨迹实际计划终点，须覆盖所有字段和热采样。

生成JSON只提供目标时刻，writer/observer真实字段与代码调用由Cursor实现并短测。samples/SYNTHETIC_SCHEDULE_ONLY是虚构时间示例，不能当真实case参数。
