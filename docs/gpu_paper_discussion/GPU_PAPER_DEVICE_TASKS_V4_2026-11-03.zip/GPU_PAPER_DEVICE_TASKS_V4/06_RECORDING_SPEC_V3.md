# V3记录规范：完整字段、分层采集与计时边界

日期：2026-11-03。这是V2的增量补全，保留原174字段及案例；不是已经运行的实验报告。

## 范围与设备

4090＋64核CPU服务器负责公共开发、A组精度、B组规模/group、C组主性能与VTP。3090 Ti、2080S、H20仅按现场已有条件做共同规模配对。没有AMD/Intel GPU购置或测试任务，没有其他SPH软件比较，没有多GPU队列。原始型号必须现场打印，服务器是否恰为64物理核也要核查。

本包收录已查文献的相关指标家族并补足记录格式；不声称穷尽所有GPU论文。多GPU通信/强弱扩展、跨软件、跨厂商指标列为范围外。硬件计数器、roofline、能耗等字段必须有采集尝试或适用性记录；不能因缺工具伪造数值，也不为凑齐指标开发新物理模型。

## 采集分层

1. 每次运行：环境/输入/精度、真实规模与步数、总墙钟、必要阶段、峰值内存、结果状态。
2. 全部正式性能点：固定初态和窗口三次重复，最低诊断相同；累计记录结束汇总即可。
3. 代表profile：B2和B3各L3一个已冻结短窗口，采集传输、同步、kernel、带宽、occupancy、寄存器、缓存等；工具不支持时保留命令、错误、缺失原因。
4. 低频设备监测：通常1s墙钟；短窗口不足以覆盖时说明采样不足，不输出伪峰值或能耗结论。
5. 可推导项：由可信原始量生成吞吐率、字节/粒子、阶段占比、加速比、能耗、重复波动；保留公式与分母定义。

## 计时账本

主性能是固定物理窗内完成所有必需计算的wall_solver。包含host调度、物理/邻域/排序/耦合、必需传输和等待。benchmark关闭VTP/restart，最低诊断仍留在solver时间内，并可作为其子项报告；不得把已包含的诊断再次相加。

wall_solver_window_inclusive是整个测量窗墙钟；benchmark中应与wall_solver一致（计时边界一致）。展示运行允许将有清晰完成边界的输出单列，但不拿从展示时间事后扣除I/O的结果替代三次主benchmark。

输入读取属于init子项。init可细分input、geometry、levelset、particle_generation、initial_relation、initial_device_setup；不可分时报告合并范围。warmup、prewindow、窗口、窗外I/O、postprocess、finalize均需scope树指定父子关系，只有同父互斥兄弟项才相加。warmup若位于prewindow里，不可在进程账本重复计入。wall_process覆盖进程启动至退出；外部计时起点与进程内起点差异列unaccounted。

同步等待的host时间常与GPU执行重叠；它不是求解时间之外的新成本。event时间、host提交时间、等待时间不得简单相加，也不能用其总和取代求解墙钟。融合kernel按真实融合组报告，不强拆。计时起终点确认所有相关队列完成；不要为细分在主运行逐kernel增加同步。当前分支的wait路径必须现场审查，V2历史观察不是新代码已验证事实。

## 原始数据与缺失规则

每条记录须有run_id、record_kind、scope及单位；CSV空单元格=未知/null，不等于0。模板为template；示例为synthetic_example；只有真实运行才可写measured。逐字段measurement_status使用measured/derived/estimated/unsupported/not_applicable/permission_denied/not_collected。missing_metrics.csv保存字段、状态、原因、工具错误证据和补救动作。必需基础字段缺失阻止正式放行；硬件计数器受限不阻塞已合格主性能，但明确覆盖缺口。

每run文件清单与列名见templates/，run_manifest兼容保留V2字段。run_key规范JSON包括源码/输入/初态/数值参数/精度/实际物理窗/输出与诊断/基础设施政策/计时定义；排除设备、rep和浮动耗时。硬件比较含统一group政策；CPU group为NA。编译目标差异单独审查而非盲目hash不等就拒绝；不同CPU/GPU二进制hash本就不同。CPU线程扫描只允许线程配置这一实验变量变化。planned_runs里的迁移ID仅为新计划，已完成旧run不可改名冒充新运行。

## 工作量、内存与派生量

按模块累计sum(N_updated)，动态粒子数不能用末帧N乘步数；固体/声学/扩散子步分开。MPPS_proxy保留旧兼容口径，同时报告真实模块更新率。MNIPS_est注明有向邻接、重用次数、采样估计和误差范围；仅有邻接数量不等于真实kernel访问次数。不同软件文献的MIPPS等缩写分母可能不同，不直接拼榜。

峰值显存分别记录监测采样峰值和allocator跟踪峰值；设备总占用不冒充本进程分配。粒子/邻接/cell/排序临时内存尽量用分配账本获取；无法拆分保留null。字节每粒子标明总body或实际更新body。五档最大成功N只是已验证规模，不是硬件理论容量。不新增无界OOM搜索。

三次重复保存每次原始值，汇总median/min/max、样本SD及CV；n=3不提供未经依据的高置信度结论。阶段加速比按配对阶段CPU中位数/GPU中位数，不平均各kernel加速比。整体主加速比同样由同配置三次统计计算；end-to-end另报，不能混用旧论文时间。

## Profiler与能耗

GPU profiling原始报告保留，CSV使用工具原metric名与单位并附语义映射。occupancy不是nvidia-smi利用率；DRAM带宽不是产品页峰值带宽。replay次数不是重复样本。profile总耗时不混入benchmark。Roofline需可信操作计数、DRAM字节及相应精度基线；无法获得则NA，不用理论FLOPS反推实测。

功率积分只表示观测GPU窗口能量，记录边界、采样覆盖率和积分方法；不能代表整机，也不能与CPU包能量冒充整机公平能耗比。能量每粒子更新仅在同工作量口径下派生。无需购买仪器或开启系统权限。温度/频率/降频是排查证据，不由utilization推断带宽瓶颈。

现有优化可开关时可做代表点消融；没有开关则记not_applicable，不为本任务制造新的未优化求解器。编译器比较列可选；必须保存所有构建元数据。

## 验收

- 主字段在短测中真实写出；样本不可并入run_registry。
- 同层计时闭合并记录other/residual，5%只作排错提示。
- B2/B3各做普通计时与详细计时的短窗口配对，报告T_on/T_off-1；改变初态或窗口不得配对。
- 其他GPU与CPU不重跑A组；同服务器CPU性能与GPU性能串行调度，避免资源争用。
- 原始CSV/JSON、构建日志、profile和异常证据可追溯；缺失字段有理由，不填0占位。
