# GPU论文任务与逐例采集方案 V4

日期：2026-11-03。基于V3补齐本轮的逐case输出与执行配置；当前是任务与模板，没有替用户运行远程物理计算。

**先发给4090端Cursor：11_EACH_CASE_EXECUTION_AND_OUTPUT.md、12_EXACT_SAMPLING_RULES.md及case_cards/对应案例。** 然后接上10、06的公共采集实现。11/12及case卡覆盖旧文档频率/代表配置冲突。

## 新增

- 11张逐case卡：计算内容、输入、必收物理量、性能量、采样规则、VTP字段、终点和验收。
- case_execution_matrix.csv：每种配置的设备/分辨率/精度/重复/曲线/场输出。
- case_output_schedule.csv及output_schedule.csv：逐例输出矩阵。
- tools/freeze_output_schedule.py：用真实T/P/事件窗口等生成绝对时间/迭代列表，仅做配置绑定，不假定求解器已有此接口。
- schedules/*.input.template.json：逐case绑定输入，所有待定物理值为null，不能直接正式运行。
- planned_runs.csv由258条变261条，增加B1/B2/B3各1条代表showcase；C组3条展示已有。A组代表GPU FP32 L2验证直接保存VTP，无额外A展示轨迹。

## 已保留的V3内容

282字段（原174＋108新增）、20类记录、19种CSV模板、元数据JSON、虚构填表示例、文献来源和计时规范。主端4090＋64核CPU；其他已有GPU共同规模配对；不新增跨厂商/跨软件/多GPU实验。

## 一次提交与重复

A组每种精度/分辨率计算一次完整验证。B/C每配置一次提交，由runner完成3次正式性能重复，并仅在指定代表配置加一条展示（可复用已有合格场数据）。不是要求每个配置都多跑展示，也不能承诺一条有VTP轨迹等同3次无输出性能重复。profile和计时开关另为少量代表短窗。

绝对秒数、稳态/振动起点和性能窗口必须现场用已有结果或短先导冻结；本包给确定的采样公式和点数，不编造所有case相同End_Time。输出时间不自动改变求解器时间步。


---

# 每个案例、配置与输出的执行总表 V4

日期：2026-11-03。V3有总体频率但不够逐例落地；本次增加11张case_cards、配置执行矩阵、逐例输出矩阵，以及将时间规则绑定成绝对时刻JSON的脚本。

## “只跑一次”的准确含义

A组每档/每后端精度一条验证轨迹；代表GPU轨迹同时写曲线和VTP，避免为论文作图再跑A组。B/C每配置一次提交完整任务，脚本内仍有三次正式性能重复；不能把重复降为一次。基准禁止VTP时，5—10组场来自一条代表showcase轨迹，已有符合条件的数据可复用；否则每例确实额外一条展示轨迹。不能同时承诺“全轨迹多帧场输出”“三次无I/O主性能”而又只有一条轨迹。

B组新增3条代表showcase计划，C组原已有3条；不为每档/每group/每GPU新增展示。若用户已跑完数据，先检查可复用性，不盲目重跑。普通短测可以延续成展示轨迹，但不得将其受输出影响的计时当正式性能重复。CPU/GPU性能重复在同服务器串行排队。

## 主配置表

| 组别 | 计算配置 | 曲线 | VTP | 性能 |
|---|---|---|---|---|
| A1—A5 | L1/L2/L3 × CPU FP64/CPU FP32/GPU FP32，各1次 | 每条都按对应case规则输出 | 仅GPU FP32 L2，5—8组 | 记录耗时，不设3次主性能 |
| B1—B3 | 4090 GPU/CPU五档各3次；其他已有GPU COMMON各3次 | 51点最低诊断；B1迭代100点 | benchmark关闭 | 全调用累计、结束汇总 |
| B组group | 4090 L3 ×32/64/128/256，各3次 | 同主性能 | 关闭 | G64满足全部条件可复用 |
| B/C展示 | 每例仅4090代表档1条 | 100点及适用事件/周期/热窗 | 8组为主 | 不混入主性能重复 |
| CPU线程 | B2/B3 COMMON，1/8/16/32/64物理核 | 同主性能 | 关闭 | 每点先导1次，报告点补至3次 |

## 逐例表

- [A1 二维Poiseuille](case_cards/A1.md)：按冻结几何和Re计算通道流，验证速度剖面、流量和稳态；保持增删粒子及边界规则一致。 曲线规则 `uniform100`；场规则 `transient5`。
- [A2 二维梁振动](case_cards/A2.md)：固定夹持、材料和激励，计算自由振动及变形；三档分辨率核对频率、振幅、能量。 曲线规则 `cycles100`；场规则 `cycle8`。
- [A3 窗框D4或D7传热](case_cards/A3.md)：只选已冻结D4或D7，保持多材料导热及Robin边界，验证温度分布、热流和稳态收敛。 曲线规则 `uniform100`；场规则 `transient5`。
- [A4 二维两相溃坝](case_cards/A4.md)：保持两相物性和界面/边界模型，计算溃坝界面、前沿及压力关键事件。 曲线规则 `event100`；场规则 `event8`。
- [A5 圆柱＋柔性尾板FSI2](case_cards/A5.md)：标准尾板双向FSI；流体、结构子步、压力/黏性载荷和夹持约束全部开启。 曲线规则 `cycles100`；场规则 `cycle8`。
- [B1 三维复杂几何单分辨率粒子生成/松弛](case_cards/B1.md)：几何和level-set预处理、粒子生成、初始邻域、固定迭代松弛；另记录达到同质量目标的时间。 曲线规则 `iterations100`；场规则 `iterations8`。
- [B2 三维溃坝性能基准](case_cards/B2.md)：完整动态流体计算，含cell、排序、inner/contact关系、规约和物理积分；五档规模及共同规模跨设备。 曲线规则 `window51`；场规则 `evolution8`。
- [B3 三维扭转柱性能基准](case_cards/B3.md)：固定材料/激励/约束，完整固体积分、阻尼及真实需要的关系更新；五档与共同规模硬件比较。 曲线规则 `window51`；场规则 `cycle8`。
- [C1 工业齿轮箱](case_cards/C1.md)：成熟冻结工况的流体、运动、黏性生热、热扩散和热边界；不计算contact factor/覆盖率专用诊断。 曲线规则 `industrial51`；场规则 `industrial8`。
- [C2 工业搅拌](case_cards/C2.md)：冻结成熟单/两相版本和桨叶运动，完整移动边界/接触及流体积分；不为论文添加新混合模型。 曲线规则 `industrial51`；场规则 `industrial8`。
- [C3 两相储箱换热与晃荡](case_cards/C3.md)：冻结两相流热、相间换热和晃荡运动；不增加相变/EM；性能窗保持全部热操作开启。 曲线规则 `industrial51`；场规则 `industrial8`。

## 启动前一次完成的准备

1. 读case卡和05中的物理输入，核对源码、实际writer变量名、单位、测点、参考数据。
2. 用已有结果或一个可延续的短先导冻结T/S/P、事件[a,b]、dp/N与窗口。没有足够证据不能编造秒数。
3. 将真实数值写进配置，调用tools/freeze_output_schedule.py生成JSON。该脚本只做时间表，不执行物理计算。根据实际代码写对应runner接口，不能假定仓库已有本包CLI。
4. preflight核对每种配置的CSV、VTP、性能字段，打印预期点数与文件数；所有后端使用同一公共时刻政策。
5. 一次提交该配置的任务，由runner完成全部模式/rep，退出后核对文件和原始记录完整性。

case_execution_matrix.csv按配置家族描述所有组合，planned_runs.csv展开原运行与新增B展示，其他profile和插桩检查仍见supplemental_recording_runs.csv。现场线程正式补重复/适用额外展示运行由runner登记唯一run_id，不把计划数当实测数。


---

# 可执行采样规则与适用边界

这些数量是本次论文的工程采集方案，不是文献统一标准。T/S/P_ref/W/I来自先导或已验证结果，启动正式长任务前必须绑定成真实数值。不能从参考图的展示时刻推断原始探针间隔。

## 曲线

- uniform100：选定时间窗[S,E]，q_j=S+j(E-S)/99，j=0..99，100个目标点，含两端。A1/A3通常S=0；稳态最终剖面额外一次。若A3为迭代/伪时间轴，直接用iterations100或显式说明轴单位。
- cycles100：参考周期P_ref与起点S固定，E=S+4P_ref；同样100点。约每周期25点是起点，须与先导原有较密探针对照幅值/频率/相位；不满足登记误差标准则增点，只在所选周期窗加密。所有后端沿用同一P_ref和时间窗。
- event100：基础[0,T]100点，额外[a,b]21点并去重。压力关键事件还须用原有合法observer时间级别核查是否解析（声学或对流以该实现为准），不足就局部加密。在线保留峰值/时刻；不得用稀疏目标点插值制造峰值。事件区间不包含冲击则先导不通过。
- window51：正式性能窗[t_a,t_b]51点，间隔W/50，低成本物理一致性诊断；物理必需运算不降频。各后端执行同一observer和写出政策，其成本包含在solver。
- industrial51：benchmark同window51；showcase流动/扭矩在固定4周期窗100点，长热曲线如适用另固定[H0,H1]100点。温度点不自动触发VTP。若100点漏掉用于物理结论的尖峰须局部加密；不做高频峰值结论时可仅报告均值/低频变化。
- iterations100：0..I内等分100个整数目标迭代，四舍五入并去重；若I<99最多I+1点。残差依照已有低成本方式累计/采样；昂贵质量在0、中点、I三次。固定迭代与同质量耗时分开。
- 启动健康检查：A2/A5/周期展示可在[0,S]增加51个低成本检查点；与观测窗去重。这不是论文主曲线，也不意味着VTP同步增加。

所有物理采样记录requested_time和actual_time。一次合法步跨过多个目标点时只保存一条真实状态，并记录未解析的目标点；不得把同一状态复制成多次观测或回填假时间。正式前检查实际dt足够小，必要时增加观察窗口或减少目标点，不擅改物理步长。跨CPU/GPU曲线可在合法公共网格比较，保留原始时间，不能用时间扭曲消除相位差。

## VTP：只在代表轨迹，默认5—8组

- transient5：0.2T、0.4T、0.6T、0.8T、T，A1/A3末帧必须通过冻结稳态检查。
- cycle8：S_f+kP_ref/8，k=0..7，S_f选观测窗内最后一个已建立代表周期的起点；初始/几何预览额外1组可选。必要最大变形时刻可替换一帧或增1帧，总数不超过10；必须用实际输出状态作图，不保证粗相位帧恰为极值。
- event8：0、a/2、a、a+(b-a)/3、a+2(b-a)/3、b、b+(T-b)/2、T，去重。围绕关键撞击而不是全程密集输出。
- evolution8：展示窗[S_f,E_f]中归一化0、0.1、0.25、0.4、0.55、0.7、0.85、1，共8组。
- iterations8：0、1、0.01I、0.05I、0.2I、0.5I、0.8I、I，整数化去重；小I点数可少于8，说明即可。
- industrial8：代表周期8个相位；若展示温度长程，把一组额外热末态加入（共9组），热末态与已有时刻重复则去重。无周期/无稳定周期时用evolution8并说明。禁止为了9帧强行计算未冻结的昂贵长程。

场数指同一物理时刻一组：多body分别输出可对应多个.vtp文件，不能把“8组”误认成整个case只有8个文件。冻结表列各body/字段/压缩及估计总字节。

## 性能/资源

时间、calls、步数、dt、实际更新量每次调用累计在内存，结束写一次；可选30s墙钟累计日志刷新，只复用现有同步点。显存/RSS/功率等外部采样1s；高开销邻居/cell统计仅窗口起中末，必要时代表profile。普通性能run不在每个曲线点重新采集全场、邻居或硬件计数器。字段无法采集有missing_reason，不补0。


---

# 避免完成后补跑的逐配置检查

- [ ] 实际case/源版本/几何/模型/dp/N、精度/group/CPU线程已冻结。
- [ ] [0,T]、性能[t_a,t_b]、周期P_ref/S、事件[a,b]、迭代I等适用值已填；不适用有理由。
- [ ] 绝对采样时刻JSON生成且hash写manifest；所有后端同一时刻政策。
- [ ] 每个probe的源码实现、位置、单位、物理量定义明确；实际writer字段名和本包语义已映射。
- [ ] CPU/GPU短测真实生成完整表头及至少2个采样点，pressure/tip/temp不因漏绑定为空。
- [ ] 每种mode的VTP开关正确，代表轨迹预计5—10组；多body文件数量与存储估计已打印。
- [ ] 所需峰值/振幅/频率/相位由先导原始数据做降采样核查；不以“100点”替代检查。
- [ ] 每调用累计时间/calls/步数/更新量，结束汇总；传输等待不重复算；未测有原因。
- [ ] checkpoint仅性能起点恢复真正需要时创建；不为每帧VTP导出完整restart。
- [ ] 一次提交配置，runner依次完成需要的rep/mode；同服务器CPU/GPU性能队列不争资源。
- [ ] 结束核对实际帧数、采样时间覆盖、数值状态、物理参考和原始日志；失败不自动变参数混入原配置。

本清单降低因遗漏数据而重跑的风险，不保证新适配case不会出现数值失败。必要的三次性能重复及先导不是遗漏造成的重复工作。


---

> V4补充：逐case配置/频率/场输出以11、12及case_cards为准。先绑定真实时刻并执行13的输出preflight。

> V3（2026-11-03）：主协调端为4090＋64核CPU同一服务器。记录细则以06、07为准；旧文档与之冲突时采用06、07。所有结果仍待现场实测。

# 第一部分：4090工作站 Cursor 开发与运行任务书

## 交给Cursor的目标

先阅读00_START_HERE、04_DATA_CONTRACT、05_CASE_PARAMETER_TABLES。本机负责全部公共开发与先导，完成A组精度、B组五档规模/group、C组三个代表工业窗口，并生成其他设备可直接复用的冻结包。精度对照和正式CPU基线均在本服务器CPU上完成，按精度与性能用途分别记录。

授权范围：检查和改造用户指定本地repo、编译、短测、配置记录、按放行队列本机运行；不推送主分支、不改变其他用户工作、不替用户清理未提交文件。先报告真实路径和状态，不假定已有远程权限或引用SSH记忆里的地址。

## T0：盘点与隔离

1. 查看当前工作区、AGENTS、git状态、分支、SHA和依赖。不要reset/clean已有工作；用独立实验分支/worktree或用户现有允许的工作目录。
2. 实际打印GPU名称、可用显存、驱动、SYCL设备/backend，以及CPU/内存。型号与计划不符时按实际硬件命名并报告。
3. 查找下表候选；不同本地分支允许路径不同，记录真实来源。仓库历史核查SHA仅作定位参考，不要求回退掉新开发。

| ID | 已核查的主仓库候选路径 | 现场要确认的事 |
|---|---|---|
| A1 | tests/tests_sycl/2d_examples/test_2d_mixed_poiseuille_flow_sycl/mixed_poiseuille_flow.cpp | CK CPU/GPU与解析剖面、分段timer |
| A2 | tests/tests_sycl/2d_examples/test_2d_oscillating_beam_sycl/oscillating_beam.cpp | 与CPU模型/初始激励一致 |
| A3 | tests/2d_examples/test_2d_windows_frame_diffusion_D4/ 或 D7/ | 主仓库已核查传统CPU；本地查GPU实现和COMSOL数据 |
| A4 | tests/tests_sycl/2d_examples/test_2d_two_phase_dambreak_ck/two_phase_dambreak.cpp | 相间模型CPU-CK等价 |
| A5 | tests/2d_examples/test_2d_fsi2/fsi2.cpp | 标准圆柱+柔性尾板；本地查GPU移植，禁止换成浮体 |
| B1 | tests/tests_sycl/3d_examples/test_3d_particle_relaxation_single_resolution_sycl/particle_relaxation_single_resolution_3D.cpp | 替换为成熟复杂几何，检查体填充/薄壳语义 |
| B2 | tests/tests_sycl/3d_examples/test_3d_dambreak_sycl/dambreak.cpp | 动态邻域与实际步数 |
| B3 | tests/tests_sycl/3d_examples/test_3d_twisting_column_sycl/twisting_column.cpp | 参考关系实际是否重建 |
| C1 | 工业齿轮箱：本地冻结分支 | 精确源文件、CPU-CK对照、热模块、旧contact-factor混合区 |
| C2 | 已知程序名线索test_3d_stirring_two_phase_sycl | 单相/两相选择当前成熟版本，不为论文新加物理 |
| C3 | 已知程序名线索test_3d_tank_sloshing_heat_transfer_ck | 热晃荡模型及CPU等价路径 |

历史主仓库核查SHA：1612330e44c8947406f24b6756449e80dcd7158e；SPHinXsim曾带独立内嵌SPHinXsys，不能混用版本。EinSIMO远端访问未核实，优先使用用户本地已有代码。source_inventory.csv逐例列真实repo/ref/SHA/CPU路径/GPU路径/参考数据/状态。

## T1：先完成公共采集与精度构建

1. 建CPU-CK FP32、CPU-CK FP64、GPU FP32三个隔离构建目录；CPU型号不作性能门槛。尽量同一CK源与相同编译优化政策。每次启动打印sizeof(Real)、实际device、group与版本。
2. 之前核查的根CMake在SYCL=ON时强制FLOAT=ON。GPU FP64只是A2/A3中档可选敏感性实验：先检测fp64支持，再在实验分支让精度选项可配置，检查类型/常量/库/原子路径；不盲目把一个开关当作成功。若需要大改或不稳定，写unsupported/deferred，不阻塞GPU FP32主线。
3. 增加实验配置/统一日志、窗口计时、状态检测、资源监测和汇总脚本。沿用现有库接口，避免为计时重写物理算法。
4. 修复Poiseuille缺少分段起点更新等已有timer问题；审查其他案例计时闭合、已有同步、实际结束时间。
5. 去掉齿轮箱contact factor/覆盖率统计的执行和输出，保留真实黏性力；物理必需力/热操作不能删。对比开关前后少量物理轨迹，确认删除的是诊断。
6. 实现preflight：输入hash、参数/单位、精度、时间窗口、body数目、必要输出、group可用性、失败状态。补齐字段再长跑。

交付：支持至少单case、单配置运行的runner；只做计划的dry-run；失败可恢复且不覆盖目录；日志解析/计算误差/汇总表脚本。不要求测试所有仓库模块，只验证本次受影响运行路径。

## T2：A组适配与物理验证

每例三档×CPU FP64/CPU FP32/GPU FP32各1次。粗档短测先检查必要字段真实写出，再完成全轨迹。输出05中全部验证量，以及L2/Linf、振幅/频率/相位、收支等适用指标。参考缺失标为待补，不拿CPU结果冒充独立物理真值。

### A1 Poiseuille

以已核查通道DH/dp=20/40/80为起点。记录Re实际定义、mu、压差、坐标/入口函数及验证剖面位置。开启粒子增删时保存质量收支与N(t)。传统CPU对照若边界/积分不同，不与CPU-CK比较混名。时间长度以达到所选稳态/瞬态比较要求为准。

### A2 梁

厚度方向10/20/40层起点；固定梁几何、激励、本构、阻尼。保存梁端两分量、频率、振幅、能量。小振幅/细长理论不适用时使用合适文献/高精度参考。L2选做GPU FP64，不为此重跑全部精度矩阵。

### A3 窗框

优先D4，若D7已有成熟GPU与完整COMSOL结果则用D7，只选一个。找到参考数据文件/参数来源，记录来源、网格和稳态条件；没有数据不伪造。现有传统CPU的局部导热系数、多材料接口、Robin内外边界、局部减弱换热要等价迁移到CK/GPU。先用已有简化扩散短测检查符号/热流，再跑窗框；Neumann不另扩成主文第六例。

三档dp由窄区/材料厚度可解析性决定，先导后填写resolution_table。稳态以温度残差和内外热流收支判定，不仅凭原源码end_time。若采用热扩散伪时间推进，注明物性与时间量纲，不能把无热容定义的伪时间当真实热响应。

### A4 两相溃坝

dp=0.05/0.025/0.0125可作源码尺寸下的起点，先看CPU/显存成本；固定两相密度比、声速、重力和界面模型。保存压力峰值/时间、界面、前沿、各相质量和机械能。参考实验/文献必须匹配几何和无量纲条件。

### A5 标准FSI2

查本地移植；若无，按CPU fsi2建立CK/SYCL版本。迁移流体、尾板结构积分、固定夹持、压力与黏性双向力、结构法向/平均速度、固体子步和关系更新。不得替换为刚体或主动游鱼。

主仓库传统头文件曾见全局dp=0.1、尾板厚0.2，但固体可另有adaptation；必须统计真实尾板层数，不盲用这个全局默认作为精度档。固定流固dp比，先导选择三档实际可解析尾板厚度。检查已有reload粒子开关与初始文件完整性，所有后端使用同一初态。

子步保护触发、非正dt或不完整推进判失败；核对力传递方向、平均速度时间区间、参考构型关系与接触关系。记录尾端轨迹、稳定周期统计、压力/黏性载荷；对齐采样时刻，不用时间扭曲替代相位对比。

交付：A_case_validation.csv、逐例误差/参考来源与图、三档对照原始数据、待解决项。A5/A3若卡住，其余合格case继续排队；状态写明不能宣称全组已完成。

## T3：B组五档性能与G扫描

1. B1选择用户可公开、复杂但已能稳定生成粒子的单分辨率三维几何；例如已有容器/叶轮/复杂零件。不引入多分辨率粒子算法。几何文件和hash冻结，确保无缺失/错误缩放；不把预设薄壳生成当实体体填充。
2. 三例均先L3中档预热/短窗口，统计N、显存/主存与时间、邻居数量，定L1—L5和共同规模候选。显存预估只作估计，COMMON待最小显存端短测确认。
3. 每例L3扫描group32/64/128/256，各3次。保持同初态、窗口、输出和计时政策；先分析完整求解与阶段时间，不只挑某kernel的最快点。默认64主线；若改统一设置先冻结后重跑。
4. 五档主性能各3次。B1固定1000次松弛可沿用源码起点，另记录到达预定粒子质量阈值的迭代及耗时（若未达到记录未达到）。B2/B3固定物理区间且保存实际各级步数。原默认20s/0.5s不自动成为短窗口要求，先导选代表段后冻结。
5. profile每例只取一个代表规模，必要时加最细档；先保留兼容MPPS/MNIPS，再按真实模块步数给工作量，不虚构相同更新操作。

交付：resolution_table.csv（dp/N/body分解/COMMON映射）；group_sensitivity.csv及图；B_scaling.csv、阶段组成、内存曲线、run_registry与失败日志。

## T4：工业C组三个代表规模

每例固定成熟工况与单一COMMON分辨率，保留全部原有物理求解、关闭专用contact factor/覆盖率诊断。搅拌优先稳定版本；储箱不为本论文新增相变/EM；齿轮箱保留已验证热模型，不能为提速关热后仍称热耦合。

先做小/共同规模短测CPU-CK与GPU核查输出；选性能窗口，足够体现正常移动/界面/热操作，不只计静止启动段。周期运动优先覆盖多个代表周期，具体窗口以先导/预算冻结；记录前窗成本。热长程展示和短性能窗口分开：本机GPU可以完成展示，若过于昂贵保留短展示、把长展示列可选并记录预计成本，不让其阻塞配对包。

每例GPU性能窗口3次，物理展示轨迹1次，可复用同一条轨迹的输出而不重复计算；若没有全程轨迹则不编造。选定帧、restart与最低诊断见05。原gearbox 2.1s是可参考窗口，不自动要求所有新工业case都跑2.1s。

交付：C_common_benchmark.csv、阶段图、最低诊断对照、展示帧、初态/restart及hash、CPU/其他GPU待跑队列。若2080S装不下代表规模，可冻结额外小规模共同点并在4090配对，不能私改其他卡dp。

## T5：冻结包与验收

冻结包提供所有case源代码/依赖说明或可获取ref及补丁、资产、初始粒子/restart、配置、group和计时政策、完整hash、run清单、构建/运行/解析说明。若工业资产不能对外公开，包仍须供用户授权的设备复用，不擅自公开。

输出README_HARDWARE_HANDOFF，给出一条先preflight/dry-run再单点运行的现场可用命令（只能填已经实现并试过的实际命令），不要在交接里发明不存在的CLI。分发给CPU64和其他GPU时不要求其重做A组或选择参数。

验收清单：
- [ ] 真实device与Real类型可见；A组三档、参考与FP32影响有结果/明确阻塞状态。
- [ ] A5为柔性尾板双向FSI；A3为选定窗框并有独立参考来源。
- [ ] B组三例五档、G扫描、三次性能重复、内存/阶段数据齐全。
- [ ] 工业组三例代表窗口可重跑，必要物理保持、专用统计已删除。
- [ ] 同一case across-device条件可由hash、配置、窗口核对。
- [ ] 计时闭合、失败判定、重复目录、summary解析在短测验证。
- [ ] 冻结包可在一个干净目录复现至少一个短测，不需要手动改物理源码。

最终给用户：已完成/待完成清单、运行数量、主要误差、group结论、资源/时间预算、CPU64与其他GPU交接包路径。没有执行的任务如实写pending，不能用计划参数填结果。


---

> V4补充：逐case配置/频率/场输出以11、12及case_cards为准。先绑定真实时刻并执行13的输出preflight。

> V3（2026-11-03）：主协调端为4090＋64核CPU同一服务器。记录细则以06、07为准；旧文档与之冲突时采用06、07。所有结果仍待现场实测。

# 第二部分：64核CPU服务器 Cursor 任务书

## 目标与前置条件

阅读00、04、05；接收4090端冻结的experiment_bundle。负责同源FP32正式CPU性能基线，不重新选择物理模型、COMMON、group政策或诊断策略，不重做A组精度。该任务不依赖GPU在本机可用。

包未到可先盘点CPU型号、物理核/逻辑线程、NUMA、内存、编译器及依赖并估算构建准备；物理输入/窗口未冻结前不提交正式长任务。禁止基于旧论文CPU时间与新GPU时间直接计算加速比。

## C64-0 环境与配对检查

1. 保留已有工作，用隔离工作目录/分支接收冻结包；验证源码与资产hash、experiment_revision。每case可能来自不同分支，按source_inventory构建。
2. Release构建CPU-CK FP32，启动打印sizeof(Real)=4和host-parallel后端。GPU精度验证中的CPU FP64不是此处性能基线。
3. 使用同版本编译器与尽量相同优化/fast-math政策；不可避免差异记录到manifest，不能默默替换数值算法。SIMD/本机优化flags也记录。
4. 识别实际64个物理核与SMT/NUMA布局；以拓扑而非连续CPU编号猜测绑核。线程限制须对TBB真实生效并核查，别只设置OMP变量后假定TBB已受控。
5. 测一个B组短窗口和一个工业短窗口，核对输入/粒子数/步数/物理诊断、计时和输出模式，确认与4090版本一致。

## C64-1 CPU线程敏感性（先于大批长任务）

| 案例 | 规模 | 配置 | 重复 |
|---|---|---|---|
| B2 3D dambreak | 冻结COMMON（预算不足时由协调端另冻结代表档） | 1/8/16/32/64物理核 | 每配置先导1次；正式报告点补至3次 |
| B3 3D twisting column | 同上 | 同上 | 同上 |
| 可选SMT | 与上述同规模 | 64核/128线程，仅实际可用时 | 代表点3次 |

相同配置使用同一NUMA/首次接触政策、无其他大负载。报告CPU基线64物理核，并标出扫描中实际最快配置；如果SMT更快可附SMT结果，但不把128线程叫128核。不得为每个case无记录地挑不同核数。

交付cpu_thread_scaling.csv、拓扑与绑定配置、实际线程数证据、性能曲线及建议。

## C64-2 B组规模配对

| 案例 | 主任务 | 必须记录 |
|---|---|---|
| B1 粒子生成/松弛 | L1—L5，各3次 | 预处理总时间、level-set/生成/松弛等阶段；质量和迭代；内存 |
| B2 3D dambreak | L1—L5，各3次 | 相同物理窗口；各级步数、MPPS/MNIPS估计、邻域/物理阶段、内存 |
| B3 3D twisting column | L1—L5，各3次 | 相同窗口；结构步数、实际关系更新、阶段、内存 |

先共同规模和中粗档，最细档先导估算。若预计明显超出用户可用预算/内存，不私自更改dp或窗口：记录deferred、预计耗时、已完成覆盖；至少完成COMMON及三档可负担规模，保持与GPU有配对。待协调端决定是否新增所有设备统一短窗口。不能用粗档时间线性外推充当最细档实测。

所有正式B结果同一已声明CPU配置；线程扫描单列。无需运行GPU group扫描。

## C64-3 C组三个工业窗口

齿轮箱、搅拌、热晃荡各COMMON档3次。用冻结相同初态/restart与窗口；先验证跨后端恢复支持。若必须从t=0推进，记录前窗和窗口时间，不把GPU恢复运行与CPU完整推进时间直接相除。无需在CPU重复长热展示。

必须启用相同物理模块、运动和热边界。关闭contact factor/覆盖率等专用统计；必要耦合力与热求解不能删除。按固定频率记录最低扭矩/温度/质量诊断和实际步数。

## C64-4 汇总与交付

输出CPU run目录及registry、thread_scaling、B/C summary与计时细目、内存、失败/延期列表。只有匹配run_key（版本/输入/规模/精度/窗口/输出）的结果才计算GPU加速比；不能把CPU线程扫描的最佳单次和GPU三次中位数不加说明比较。

检查group_time_ratio=CPU组内时间之和/GPU组内时间之和；MPPS/MNIPS口径一致；静态墙不冒充全部实际更新粒子。CPU/GPU不同自适应步数如实记录，不强行改步数使加速好看。

最终报告区分本机已测CPU结果和从交接包导入的GPU结果，说明缺失配对、compiler/NUMA差异与潜在影响。无需推送/合并仓库。


---

> V4补充：逐case配置/频率/场输出以11、12及case_cards为准。先绑定真实时刻并执行13的输出preflight。

> V3（2026-11-03）：主协调端为4090＋64核CPU同一服务器。记录细则以06、07为准；旧文档与之冲突时采用06、07。所有结果仍待现场实测。

# 第三部分：2080S、3090 Ti、H20 各GPU端 Cursor 任务书

本任务书复制给每个设备，逐台只运行该设备任务。配套00、04、05和4090冻结包。4090承担主端对应点，本次级队列不重复安排4090。

## G0：环境与设备选择

核对完整GPU型号、UUID、显存及实际可用量、主机CPU/内存/PCIe、driver、CUDA、oneAPI/Codeplay、OS和依赖。H20记录MIG/共享/功率限制（如适用）；双4090机器明确选择单一UUID，不默认多GPU。每次打印真实device，不能误选CPU backend。

保留用户现有文件，用独立构建与运行目录。从冻结源码/补丁构建GPU FP32，验证sizeof(Real)=4、库版本和数值优化政策。允许不同架构的必要target编译适配，但记录全部flags；不能借此改变物理算法。当前任务不要求FP64、A组精度、五档扫描或重新调group。

## G1：共同规模放行

每例先preflight+短测：确认输入/初始粒子/restart/hash、dp、COMMON、group、窗口、输出与4090配对一致。检查峰值显存、异常与诊断，保存环境信息。最小显存2080S尽早做初始化/短测，为共同规模确认提供结果，不需要等待所有4090长任务结束。

OOM不能自行粗化后仍标COMMON。反馈协调端：具体case、N、预留/邻居规模、显存错误、建议候选档。可选择(1)全设备冻结额外小规模公共点并补4090/CPU；或(2)该卡此点记OOM/NA，其他卡继续原代表规模。两种选择均可，不能在同表将不同dp的时间直接相除。

## G2：每卡正式队列

| ID | 案例 | 分辨率 | 次数 | 记录 |
|---|---|---|---|---|
| B1 | 复杂几何单分辨率粒子生成/松弛 | COMMON | 3 | 预处理/松弛总与阶段时间、迭代质量、显存/主存 |
| B2 | 3D dambreak | COMMON | 3 | 固定窗口总/阶段时间、步数、吞吐率、内存 |
| B3 | 3D twisting column | COMMON | 3 | 同上，固体步数/关系更新 |
| C1 | 齿轮箱 | COMMON | 3 | 固定工业窗口，含全部冻结流热模块、最低诊断 |
| C2 | 搅拌 | COMMON | 3 | 冻结单/两相与桨叶运动；最低诊断 |
| C3 | 两相储箱换热晃荡 | COMMON | 3 | 冻结两相/热/运动模型；最低诊断 |

每卡18次性能运行；不包括短测与可选profile。各卡主表统一group政策（起点64），不能私自调成各卡最优而不标明。三次同一初态/窗口，避免同时占用GPU、共享host或热降频导致的干扰；出现异常保留失败日志。

详细profile每卡最多选一个B和一个C代表点先做，若已有低开销同口径阶段计时则直接使用；无需所有点逐kernel强制同步。group专项安排在4090主端；如需研究可移植性，另建补充队列，不塞进主计划。

## G3：3090 Ti/H20可选增强，不阻塞主线

在共同规模配对全部完成后，可选C1或C3增加一个细档/更大规模，展示单卡容量与实际可运行性；也可接管昂贵长物理展示。必须记录新增dp/N、显存、物理条件和时间，作为容量展示单列；没有相同规模CPU/其他GPU配对时，不宣称相应跨设备加速比。

H20部署若不成熟，先报告具体编译/设备阻塞，其他卡继续。不能以型号推测结果或用峰值算力替代实测；禁止声称多GPU扩展性。

## G4：交付与合并

每卡输出run_manifest/physics、summary/stages/steps/body_stats/telemetry、最低诊断、环境、退出状态与run_registry，保持冻结run_key。汇总表一行一运行，结果合并脚本按硬件label和rep生成median/min/max，而不覆盖4090基准。

不同GPU在不同host上的结果标为系统级比较；表中必须列host。跨GPU速度比只对相同输入/规模/精度/窗口/输出/group政策计算。未支持、OOM和延期保留NA/原因。

最终向用户报告：该设备完成18次中的多少次、哪些case异常、相对4090/CPU的匹配结果（有数据才算）、host/软件差异、可选大规模点状态。无需重复A组、公开工业资产或推送主分支。


---

> V3（2026-11-03）：主协调端为4090＋64核CPU同一服务器。记录细则以06、07为准；旧文档与之冲突时采用06、07。所有结果仍待现场实测。

# 公共数据与计时规范

所有三份设备任务书依赖本文件。比较用途V/P/R/G/H/B/C见总表。

## 1. 运行配置与模式

每个case用显式配置控制：spacing_id及dp、后端、精度、device、work_group_size、物理结束时间/窗口、输出时刻/字段、随机种子/初始粒子文件、重复编号、排序/关系更新周期、线程/绑核。实际CLI或JSON接口由Cursor基于现有代码选择，但不能只改源码常量而不保存最终值；新增选项在help中说明并校验。

模式至少四种：validate（完整物理数据）；benchmark（最少必要诊断、主性能）；profile（少量代表窗口、详细分段）；showcase（展示帧和restart）。若分段计时可在不改变正常执行顺序且开销足够小时直接收集，可用于benchmark；否则单独profile并标注开销。不要把同步插桩profile时间混进主加速比。

## 2. 输入与运行信息：必须字段

| 字段 | 内容 | 比较 |
|---|---|---|
| experiment_revision,run_id,case_id,mode,rep | 唯一运行身份与目的 | C |
| repo,commit,dirty_patch_hash,binary_hash | 源码和二进制；补丁实际归档 | C |
| input_hash,initial_particles_hash,restart_hash | 输入、初态与重启一致性 | P/R/G/H/C |
| backend,real_bytes,precision_policy | CPU-CK/GPU/legacy、sizeof(Real)、是否混合精度 | P/H/C |
| compiler,flags,cmake,dependency_versions | Release、优化/fast-math、oneAPI/Codeplay/CUDA/driver/oneDPL/TBB等 | P/H/C |
| device_model,uuid,host_cpu,ram,pcie,os | 实际完整硬件/系统 | H |
| cpu_physical_cores,threads,affinity,numa,smt | CPU执行与资源限制 | H/C |
| gpu_memory,power_limit,clocks,mig,shared_status | 实际可用显存与设备配置；不适用NA | H/C |
| geometry,units,physics,initial_conditions,boundaries | 每例物理参数与单位、几何坐标/缩放 | V/P/R/H/C |
| dp_by_body,h_over_dp,kernel,corrections | 各body分辨率、核与修正 | V/P/R/C |
| body_active_counts,reserve_capacity,neighbor_counts | 分body工作量、预留、inner/contact邻域统计 | R/H/C |
| dt_rules,cfl,sort_policy,relation_policy | 时间离散与基础设施调用规则 | R/G/H/C |
| requested_group,effective_group,limits | 实际local size；库算子覆盖范围 | G/H/C |
| t_start,t_end,actual_t_end,window,output_schedule | 物理端点与I/O策略 | P/R/G/H/C |

未测字段写null/NA并注明原因，不能以0充当未测；必要字段未填则preflight不通过。

## 3. 原始结果文件

每run独立目录，不能覆盖；退出失败也保留记录。

```text
run_manifest.json / physics.json / environment.txt
stdout.log / stderr.log / exit_status.json
run_summary.csv / stage_timing.csv / step_stats.csv
body_stats.csv / diagnostics.csv / probes.csv / telemetry.csv
snapshots/ / restart/
```

- run_summary：窗口物理跨度、实际各级步数、初始化/求解/输出/restart/验证/进程总时间、峰值内存、状态。
- stage_timing：stage、scope、calls、inclusive_or_exclusive、wall_s、device_event_s（未测NA）、timing_method。图表使用互斥阶段，嵌套inclusive阶段不能相加。
- step_stats：outer/acoustic/solid/diffusion或relaxation迭代计数，dt范围/均值与限制来源，排序/关系更新数。块汇总即可，不必每步写盘。
- body_stats：初始/最小/最大活跃数、预留容量、采样时刻inner/contact有向邻接数量、occupied cells/桶占用（若可测）。高开销统计单独采样，不每步回传GPU。
- diagnostics/probes：按预定物理时刻采样，包含单位、body/phase/测点坐标，具体量见参数表。
- telemetry：约1s采样显存、功率、温度、频率、利用率及可取得的降频信息；用外部低开销采集，记录采样周期。CPU记录RSS和资源占用。

## 4. 计时边界

主指标wall_solver：固定物理窗口内整个求解循环时间，含必要host工作、设备工作/等待、邻域/排序和耦合。所有后端采取同样诊断/I/O政策。若排除I/O，输出边界必须确认设备完成并单独计时，不能把前面积压的设备工作错误归到I/O。另保留solver_window_inclusive，方便核查。

wall_process：进程启动至退出，包含初始化、首次设备工作、I/O和结束检查；不包含编译、人工排队。窗口前warmup可以单独报告，但不丢弃cold-start成本；从初值到窗口的推进不能在物理意义上跳过。

GPU在计时起点前和终点后等待对应设备任务完成并捕获异常。先审查现有wait路径：已核查的particle_for/reduce路径本身含wait_and_throw，不能假定所有调用都异步，也不要再为测量无意义地添加重复等待。其他路径仍逐项确认。主benchmark不为细分强制引入额外逐kernel同步；profile若这么做，明确标记为同步分段诊断。event时间仅在queue支持profiling且覆盖全部相关工作时使用，事件之和不等于墙钟。

互斥阶段建议：geometry、levelset、particle_generation/load、initial_relation；solver内cell_list、sort_scan、relation_inner、relation_contact、fluid_setup/density、pressure_density、viscous/transport/correction、solid_integration/constraint、thermal_diffusion、thermal_source、thermal_boundary、coupling/moving_body、dt_reduce、diagnostics、other；output和restart另列。实际融合算子不能虚构拆分，记录真实分组并说明覆盖内容；分组方式跨设备一致。

禁止统计接触因子或润滑覆盖率。老contact-factor计时区里真正的黏性流固作用必须保留、单列；不能把整段删掉，也不从旧时间估算扣除。力/扭矩若用于耦合是必要物理；仅用于核查时降低采样频率并列入诊断。

检查互斥阶段之和与同口径solver时间闭合，保留other与误差；起步以相对差5%作插桩排错提示，不作为通用数值精度标准。插桩开销需在一个代表窗口对比开关两种模式，不能认定微小分段时间天然准确。

## 5. 吞吐率、加速比与精度指标

主加速比S=T_CPU_FP32/T_GPU_FP32，必须相同case、输入、规模、窗口、数值算法和输出策略。CPU-CK优先；legacy CPU若算子不同单独标注，不混称纯后端加速。

保留齿轮箱论文式的兼容指标：MPPS_proxy=N_total*N_timed_step/(1e6*Twall)，MNIPS_est=N_est_inner_contact*N_timed_step/(1e6*Twall)。元数据必须说明timed_step是哪一级、N_total是否含静态墙、邻居统计是有向还是无向、仅油相还是全部相；MNIPS是估计工作量而非GPU指令数。

动态N时采用逐步或块内累计的sum(N_k)，不能用最终N乘总步数。不同物理模块有不同子步时分别报告fluid/solid/diffusion/relaxation更新工作量，不把它们当作相同的一种更新。额外遍历邻居做统计的成本不能混进主benchmark；估计采样频率、变动范围也记录。无法可信估算MNIPS的case可以NA并说明，不构造虚假可比指标。

另报告wall_per_physical_second=Twall/(t_b-t_a)、各类mean_step_wall、阶段占比、阶段加速、峰值内存、三次重复中位数及min/max。group加速基于同一规模相对基线group计算。solver组加速用CPU组内时间之和/GPU组内时间之和，不平均各kernel加速比。

A组：分别计算CPU FP64/CPU FP32/GPU FP32对独立参考的误差，以及三者相互差。CPU FP64不是物理真值。固定测点/公共采样网格或持久ID比较，排序后数组下标不当粒子身份；不同dt对齐公共物理时刻，不用DTW掩盖相位差。小量附近避免不稳定相对误差，预定归一尺度。

A组平滑场CPU/GPU差1%左右、频率差1%、幅值差数个百分点可作为先导排查目标，但不是已达到结论；最终按参考来源、离散误差及用途在正式跑前冻结容差。冲击/界面长期不要求逐粒子相等；保存峰值/到达时间/窗口统计及收支。

## 6. 五档分辨率与group规则

A组只改dp，保持物理几何、边界和模型不变；FSI流固分辨率比固定。B组L1—L5由粗到细，每档记录实际N，不能只写“百万粒子”。先导定标可用三维体填充相邻dp约1.3—1.5倍作为起点；壳层/边界带不按N~dp^-3盲推。几何过细特征在最粗档也应可解析，否则另选几何或起点。

G扫描只在4090、每B例一档（优先L3）；32/64/128/256，512为可选。先创建queue再设置group并打印生效值，避免首次queue初始化覆盖设置。校验设备和具体kernel上限、非零local size、global padding与边界保护、规约/屏障正确性；保留默认64作为起点。oneDPL内部操作不一定受该setter控制，如实记录。

主跨设备结果统一group政策，不允许各卡默默挑最快值。若选设备专属调优，单列补充实验。group改变可能改变归约顺序，必须核查诊断结果；非法点记录unsupported，不退回默认后冒充指定group。

## 7. 重复、预算、失败

三次性能重复使用同一初态/窗口，计时模式一致；它们是运行时间重复，不是三个独立物理统计样本。不得对同一GPU同时启动多个性能任务，也不得让本机CPU对照占满GPU求解所需host资源。先导时长不足则延长窗口（一次冻结后所有端一致），昂贵case无需为追求固定墙钟秒数盲目延长。

checkpoint需保留两相、热、固体/刚体、历史量、ID和积分状态，验证恢复连续性及跨CPU/GPU可移植；不通过则所有端从相同初态推进，分别记录prewindow成本和窗口成本。

任何改变物理/步进/计时范围的修复升级版本，旧结果不能混配。失败不自动调dp/group/声速/CFL后继续记在原run_id；每次重试新attempt_id。显存不足写OOM，超预算写deferred，不把NA当0。


---

> V4补充：逐case配置/频率/场输出以11、12及case_cards为准。先绑定真实时刻并执行13的输出preflight。

> V3（2026-11-03）：主协调端为4090＋64核CPU同一服务器。记录细则以06、07为准；旧文档与之冲突时采用06、07。所有结果仍待现场实测。

# 每个案例的参数、输出、比较用途总表

V物理验证；P精度；R分辨率；G工作组；H硬件；B阶段瓶颈；C条件一致。以下每行“输入”都要记录实际值、单位和来源，不能只抄字段名。“输出”要在粗档短测中确认真实生成。所有case还需04里的公共元数据。

## 1. A组：物理与精度验证

| 案例 | 要记录的输入 | 要记录的输出 | 对应比较 |
|---|---|---|---|
| A1 Poiseuille | 通道长高、dp/h、rho/mu/c、Re定义、入口速度及启动函数、出口压力、初态、边界/修正、dt/CFL、探针坐标 | u(y)、中心u(t)、Q(t)、压降、进出口累计质量、N(t)、实际步数/时间 | 解析剖面与流量V；CPU64/CPU32/GPU32差P；三档误差R；收支/步数C |
| A2 梁振动 | 梁长厚、夹持段、dp/厚度层数、rho/E/nu、本构、初始速度/位移激励、阻尼、dt、探针位置 | 尾端x/y位移和速度、主频、各周期振幅、均值/相位、动能/应变能、实际步数 | 文献/适用理论V；精度P；三档R；能量/步数C |
| A3 窗框D4/D7 | 几何/材料区、各区导热系数、rho*cp或扩散/伪时间定义、室内外温度与Robin系数、局部减弱换热区、初温、dp/h、稳态阈值、COMSOL对应配置与测点 | Phi/温度测点、同截面分布、内外总热流、热收支、稳态残差、扩散迭代数与时间 | 对COMSOL V；CPU64/CPU32/GPU32及可选GPU64 P；材料界面细化R；收敛/迭代C |
| A4 两相溃坝 | 水槽/水柱几何、两相rho/mu/c/EOS、重力、相间模型、表面张力/接触角（如启用）、dp/h、CFL、压力探针及界面采样方式 | 界面帧、水位/前沿、压力p(t)/峰值/到达时间、两相质量、最大速度/密度偏差、机械能、步数 | 文献/实验V；精度P；界面/压力细化R；守恒与步数C |
| A5 圆柱柔性尾板FSI2 | 通道/圆柱/尾板尺寸、流固各dp及比值、实际尾板层数、流体rho/mu/c/Re与入口启动、固体rho/E/nu/本构、夹持、阻尼、流固耦合/子步规则、reload初态 | 尾端x/y位移、均值/振幅/频率/相位、结构载荷（压力/黏性）、代表变形/流场、dt/Dt/dt_s、各类步数与保护触发 | 标准FSI文献V；精度P；流固同比细化R；双向传力/子步C |

A组三版本必须共享模型和初态；GPU64仅A2/A3中档可选。不同编译精度可能导致生成粒子差异，优先离线生成一次并统一载入。保存完整验证数据即可，不要求全套性能细分。

## 2. B组：五档规模、group和硬件

| 案例 | 固定物理/算法输入 | 每档规模参数 | 性能字段 | 质量/一致性输出 | 比较 |
|---|---|---|---|---|---|
| B1 复杂几何level-set/松弛 | 几何hash/坐标/缩放、实体/壳层定义、单分辨率设置、SDF网格/修正、随机种子/初始点、松弛规则与停止标准 | L1—L5的dp、实际N、表面N、level-set节点/块/网格层信息、内存 | 几何/level-set/粒子生成/初始关系/松弛/约束时间；迭代均时、粒子更新率、可信邻居估计率、峰值内存 | 表面距离误差、最近邻分布、松弛残差；固定迭代与达到同质量的迭代/耗时 | 五档R；中档group G；COMMON H；阶段B；质量C |
| B2 3D溃坝 | 水槽/水柱、rho/g/c、核/修正、dt/CFL、排序/关系周期、物理窗口 | 每档dp、流体/壁各N、inner/contact邻居统计、occupied cells/桶占用、reserve | solver/process/init/output时间、各级步均时、MPPS/MNIPS口径、cell/relation/sort/流体/规约阶段、峰值内存 | 质量、压力/水位摘要、最大速度/密度偏差、各级步数及实际终止时间 | R/G/H/B/C |
| B3 3D扭转柱 | 柱几何、rho/E/nu/本构、初始角速度分布、固定区、阻尼、dt/约束、物理窗口 | 每档dp、实际固体N、初始参考邻域数、实际重建次数 | solver/init/output时间、结构步均时、结构更新率、relation/固体积分/阻尼/规约/约束、内存 | 端部运动、能量、代表变形、结构步数、失败状态 | R/G/H/B/C |

P1旧编号本包统一为B1；旧表3D dambreak B1本包改为B2，扭转柱改为B3。脚本与CSV统一使用本包编号，禁止按旧ID混配。

## 3. C组：单一代表规模跨设备

| 案例 | 固定并归档的输入 | 性能重点 | 最低物理诊断（低频） | 不列为任务 |
|---|---|---|---|---|
| C1 齿轮箱 | CAD/粒子hash、每body dp、油量/液位、油rho/mu/c/k/cp、固体热物性、各轴omega/运动、初温、热源/边界、物理窗口 | 总/各级步均时、MPPS/MNIPS估计、基础设施/流体/黏性/热扩散/热源/热边界/运动/必要规约、内存 | 各轴扭矩及功率可由omega计算、油温及齿轮/壁温摘要、油质量、步数；热收支仅保留现有低成本量 | contact factor、覆盖率、齿轮表面分区润湿、完整多工况贡献率研究 |
| C2 搅拌 | 容器/桨叶、成熟单/两相选择、液位、各相物性、omega与启动函数、旋转轴/单位、各body dp、运动/邻域规则、窗口 | 总/阶段时间、吞吐率、移动边界/相间接触、内存、实际步数 | 桨叶扭矩、少量速度探针、各相质量；现有自由面/气含率可选 | 新增示踪剂/混合时间研究、为论文临时升级多相 |
| C3 热晃荡储箱 | 储箱/充液率、两相rho/mu/c/k/cp/EOS、相间热模型、初温、壁/环境热边界、晃荡幅频/方向/完整函数、dp、窗口 | 两相/邻域/排序/热交换扩散/运动/规约、总体与吞吐率、内存 | 少量压力/水位探针、两相平均温度、两相质量、实际步数；现成低成本热量摘要 | 新加相变或EM、完整参数扫频研究 |

三例COMMON一档，跨CPU/GPU完全一致；热模型启用的项必须真正计算。最低诊断用于H/B结果的C核查，不扩成新物理验证章节。力/扭矩若驱动物体运动必须按物理需要计算，不能低频化必要耦合；低频化仅指输出/额外诊断。

## 4. 分辨率与比较对象落地表（由先导填写）

| 案例 | 起点建议 | 正式冻结时必须填写 | 用途 |
|---|---|---|---|
| A1 | DH/dp=20/40/80 | dp、各body N、参考剖面位置/终止判据 | V/P/R |
| A2 | 厚度方向10/20/40层 | 实际层数、dp、固体N、激励/观测周期 | V/P/R |
| A3 | 由最窄材料区确定，不猜数值 | 每档dp、可解析厚度、材料分区N、稳态标准 | V/P/R |
| A4 | 源码尺寸下dp=0.05/0.025/0.0125为起点 | dp、各相/壁N、参考与窗口、CPU成本 | V/P/R |
| A5 | 保持流固dp比、足够尾板层数 | 各body dp/N、真实尾板层数、参考条件 | V/P/R |
| B1/B2/B3 | 初始化定标五档；COMMON优先L3 | 每档dp/N/邻域/显存；共同档ID；窗口 | R/G/H/B |
| C1/C2/C3 | 采用成熟有依据的代表dp | 每body dp/N、共同档、初态/restart、窗口 | H/B/C |

不要求各case粒子数相同。每档细化保持物理几何不变；壳层厚度若随dp变化，明确这是算法边界带而非真实结构几何改变，并避免拿此变化作物理收敛结论。

## 5. 结果表模板

### 精度表
case / spacing / dp_by_body / N_by_body / backend / real_bytes / reference / reference_error_L2 / reference_error_Linf / CPU64_difference / frequency_error / amplitude_error / phase_or_arrival_error / mass_or_heat_balance / status。按case填适用字段，NA必须有理由。

### 总体性能表
case / spacing / dp / N_by_body / platform / host / cores_threads / real_bytes / group / physical_window或relax_iterations / steps_by_level / wall_solver / wall_init / wall_process / mean_step_by_level / MPPS_proxy或module_updates / MNIPS_est / peak_VRAM / peak_RSS / speedup / repetitions_range / status。

### 阶段性能表
case / spacing / platform / stage / calls / wall_s / fraction / matching_CPU_stage_s / speedup / timing_mode。分组和细项分别出表，避免父子重复相加。

### group表
case / spacing / effective_group / wall_solver_median / min / max / phase_times / correctness_difference / support_status / library_scope。默认64和调优结果不能混为同一种跨设备基线。

### 发布前检查
所有表能追溯到run_id和原始文件；不录入估算伪装成实测；没跑完明确pending；旧论文归一化到2.1s的数据不与新版本直接混用。图表只呈现完成的匹配数据，设备不足不外推。


---

# V3记录规范：完整字段、分层采集与计时边界

日期：2026-11-03。这是V2的增量补全，保留原174字段及案例；不是已经运行的实验报告。

## 范围与设备

4090＋64核CPU服务器负责公共开发、A组精度、B组规模/group、C组主性能与VTP。3090 Ti、2080S、H20仅按现场已有条件做共同规模配对。没有AMD/Intel GPU购置或测试任务，没有其他SPH软件比较，没有多GPU队列。原始型号必须现场打印，服务器是否恰为64物理核也要核查。

本包收录已查文献的相关指标家族并补足记录格式；不声称穷尽所有GPU论文。多GPU通信/强弱扩展、跨软件、跨厂商指标列为范围外。硬件计数器、roofline、能耗等字段必须有采集尝试或适用性记录；不能因缺工具伪造数值，也不为凑齐指标开发新物理模型。

## 采集分层

1. 每次运行：环境/输入/精度、真实规模与步数、总墙钟、必要阶段、峰值内存、结果状态。
2. 全部正式性能点：固定初态和窗口三次重复，最低诊断相同；累计记录结束汇总即可。
3. 代表profile：B2和B3各L3一个已冻结短窗口，采集传输、同步、kernel、带宽、occupancy、寄存器、缓存等；工具不支持时保留命令、错误、缺失原因。
4. 低频设备监测：通常1s墙钟；短窗口不足以覆盖时说明采样不足，不输出伪峰值或能耗结论。
5. 可推导项：由可信原始量生成吞吐率、字节/粒子、阶段占比、加速比、能耗、重复波动；保留公式与分母定义。

## 计时账本

主性能是固定物理窗内完成所有必需计算的wall_solver。包含host调度、物理/邻域/排序/耦合、必需传输和等待。benchmark关闭VTP/restart，最低诊断仍留在solver时间内，并可作为其子项报告；不得把已包含的诊断再次相加。

wall_solver_window_inclusive是整个测量窗墙钟；benchmark中应与wall_solver一致（计时边界一致）。展示运行允许将有清晰完成边界的输出单列，但不拿从展示时间事后扣除I/O的结果替代三次主benchmark。

输入读取属于init子项。init可细分input、geometry、levelset、particle_generation、initial_relation、initial_device_setup；不可分时报告合并范围。warmup、prewindow、窗口、窗外I/O、postprocess、finalize均需scope树指定父子关系，只有同父互斥兄弟项才相加。warmup若位于prewindow里，不可在进程账本重复计入。wall_process覆盖进程启动至退出；外部计时起点与进程内起点差异列unaccounted。

同步等待的host时间常与GPU执行重叠；它不是求解时间之外的新成本。event时间、host提交时间、等待时间不得简单相加，也不能用其总和取代求解墙钟。融合kernel按真实融合组报告，不强拆。计时起终点确认所有相关队列完成；不要为细分在主运行逐kernel增加同步。当前分支的wait路径必须现场审查，V2历史观察不是新代码已验证事实。

## 原始数据与缺失规则

每条记录须有run_id、record_kind、scope及单位；CSV空单元格=未知/null，不等于0。模板为template；示例为synthetic_example；只有真实运行才可写measured。逐字段measurement_status使用measured/derived/estimated/unsupported/not_applicable/permission_denied/not_collected。missing_metrics.csv保存字段、状态、原因、工具错误证据和补救动作。必需基础字段缺失阻止正式放行；硬件计数器受限不阻塞已合格主性能，但明确覆盖缺口。

每run文件清单与列名见templates/，run_manifest兼容保留V2字段。run_key规范JSON包括源码/输入/初态/数值参数/精度/实际物理窗/输出与诊断/基础设施政策/计时定义；排除设备、rep和浮动耗时。硬件比较含统一group政策；CPU group为NA。编译目标差异单独审查而非盲目hash不等就拒绝；不同CPU/GPU二进制hash本就不同。CPU线程扫描只允许线程配置这一实验变量变化。planned_runs里的迁移ID仅为新计划，已完成旧run不可改名冒充新运行。

## 工作量、内存与派生量

按模块累计sum(N_updated)，动态粒子数不能用末帧N乘步数；固体/声学/扩散子步分开。MPPS_proxy保留旧兼容口径，同时报告真实模块更新率。MNIPS_est注明有向邻接、重用次数、采样估计和误差范围；仅有邻接数量不等于真实kernel访问次数。不同软件文献的MIPPS等缩写分母可能不同，不直接拼榜。

峰值显存分别记录监测采样峰值和allocator跟踪峰值；设备总占用不冒充本进程分配。粒子/邻接/cell/排序临时内存尽量用分配账本获取；无法拆分保留null。字节每粒子标明总body或实际更新body。五档最大成功N只是已验证规模，不是硬件理论容量。不新增无界OOM搜索。

三次重复保存每次原始值，汇总median/min/max、样本SD及CV；n=3不提供未经依据的高置信度结论。阶段加速比按配对阶段CPU中位数/GPU中位数，不平均各kernel加速比。整体主加速比同样由同配置三次统计计算；end-to-end另报，不能混用旧论文时间。

## Profiler与能耗

GPU profiling原始报告保留，CSV使用工具原metric名与单位并附语义映射。occupancy不是nvidia-smi利用率；DRAM带宽不是产品页峰值带宽。replay次数不是重复样本。profile总耗时不混入benchmark。Roofline需可信操作计数、DRAM字节及相应精度基线；无法获得则NA，不用理论FLOPS反推实测。

功率积分只表示观测GPU窗口能量，记录边界、采样覆盖率和积分方法；不能代表整机，也不能与CPU包能量冒充整机公平能耗比。能量每粒子更新仅在同工作量口径下派生。无需购买仪器或开启系统权限。温度/频率/降频是排查证据，不由utilization推断带宽瓶颈。

现有优化可开关时可做代表点消融；没有开关则记not_applicable，不为本任务制造新的未优化求解器。编译器比较列可选；必须保存所有构建元数据。

## 验收

- 主字段在短测中真实写出；样本不可并入run_registry。
- 同层计时闭合并记录other/residual，5%只作排错提示。
- B2/B3各做普通计时与详细计时的短窗口配对，报告T_on/T_off-1；改变初态或窗口不得配对。
- 其他GPU与CPU不重跑A组；同服务器CPU性能与GPU性能串行调度，避免资源争用。
- 原始CSV/JSON、构建日志、profile和异常证据可追溯；缺失字段有理由，不填0占位。


---

> V4补充：逐case配置/频率/场输出以11、12及case_cards为准。先绑定真实时刻并执行13的输出preflight。

# 物理采样与VTP输出（V3）

性能统计全部累计，结束汇总；不要求输出随物理时间变化的性能曲线。设备监测按墙钟采样，累计日志刷新可选。

物理探针/积分量与VTP独立。每例选一个代表配置，由4090保存5—10组场文件；不是每个CPU/GPU、精度、分辨率或group都保存。A组可在选定GPU validate轨迹直接保存；benchmark窗口内VTP和restart关闭。B/C展示运行独立标记，可沿用已有合格展示轨迹；不能混入三次benchmark。其余档位初末帧仅按质量核查需要保留。

平滑时间曲线以选定比较窗口50—100点为起点，不是全程/每周期的统一硬限制。稳态案例保存最终剖面与收敛检查；梁/FSI选择几个稳定周期并用先导降采样检查幅频相位；溃坝冲击局部加密，先确定事件宽度再冻结间隔。不得根据50—100点自动判断压力峰值已解析。CSV可用非均匀时刻列表，但记录实际时间，跨后端对齐公共物理时刻。

VTP围绕最终/稳定代表状态及必要演化选择5—10组，无需均匀覆盖启动全程；振动末帧不一定代表最大变形，周期流场也不应统称稳态。B1可用初始、若干松弛阶段、最终；静态温度场不必凑满10张。显式field_output_times在先导后冻结，模板不编造具体秒数。输出越过目标时刻后的首个合法步并记actual_time，不为作图随意改变积分算法。字段限位置、ID、必要速度/压力/温度/位移/应力/区域；不用专用覆盖率或contact factor。

output_schedule.csv逐case标明窗口、采样政策、字段、输出owner与配置；未冻结时间列表为TBD，不得据此提交长任务。优先二进制压缩输出，不改变所需数据精度。


---

# 文献对照与新增字段来源

- **L1 GPUs, a New Tool of Acceleration in CFD: Efficiency and Reliability on SPH Methods (2011)** — [https://doi.org/10.1371/journal.pone.0020685](https://doi.org/10.1371/journal.pone.0020685)。关联：stages; steps/s; hardware/scale; output cost。核查范围：https://pmc.ncbi.nlm.nih.gov/articles/PMC3113801/。
- **L2 Neighbour lists for smoothed particle hydrodynamics on GPUs (2018)** — [https://www.sciencedirect.com/science/article/pii/S0010465517304198](https://www.sciencedirect.com/science/article/pii/S0010465517304198)。关联：neighbor iteration; speed/memory; precision/hardware/dimension。核查范围：publisher abstract inspected。
- **L3 Fast, feature-rich weakly-compressible SPH on GPU: coding strategies and compiler choices (2022 preprint; revised 2023)** — [https://arxiv.org/abs/2207.11328](https://arxiv.org/abs/2207.11328)。关联：compiler and implementation performance sensitivity。核查范围：abstract and PDF retrieved; not every counter attributed。
- **L4 From GPU to CPU (and Beyond): Extending Hardware Support in GPUSPH Through a SYCL-Inspired Interface (2024 online / 2025 volume)** — [https://doi.org/10.1002/cpe.8313](https://doi.org/10.1002/cpe.8313)。关联：CPU strong/weak scaling; SMT/NUMA; latency; arithmetic differences; MIPPS。核查范围：publisher indexed excerpts; direct full-page access blocked。
- **L5 The Shamrock code: I - smoothed particle hydrodynamics on GPUs (2025)** — [https://doi.org/10.1093/mnras/staf444](https://doi.org/10.1093/mnras/staf444)。关联：tree construction/traversal; particle throughput; CPU/GPU; multi-GPU scope excluded。核查范围：publisher full text retrieved。
- **L6 GeoDualSPHysics: a high-performance SPH solver for large deformation modelling of geomaterials with two-way coupling to multi-body systems (2026 volume / 2025 DOI)** — [https://doi.org/10.1016/j.cpc.2025.109965](https://doi.org/10.1016/j.cpc.2025.109965)。关联：Nsight Compute; occupancy/memory optimization。核查范围：publisher excerpts retrieved; full author PDF too large for web reader。
- **L7 Computational performance of a smoothed particle hydrodynamics simulation for shared-memory parallel computing (2015)** — [https://www.sciencedirect.com/science/article/pii/S001046551500137X](https://www.sciencedirect.com/science/article/pii/S001046551500137X)。关联：CPU/MIC/GPU performance and power efficiency。核查范围：publisher abstract only; no specific energy accounting copied。

计时scope树、缺失状态、原始证据链、计时开关配对是本项目的实施规范，不冒充每篇原文均要求的参数。Roofline、cache、功率积分等作为预留或代表profile字段，不能声称这些论文全部测了这些项目。完成标准是适用指标得到真实记录或可审查缺失说明，并非强行凑满数字。


---

# 记录模板与样本

templates/是只有表头的空模板；run_manifest.template.json包含空值，不是已执行结果。

samples/SYNTHETIC_B2_GPU/是完全虚构的填表示例，所有数值仅演示关系，不代表4090或任意设备性能。record_kind=synthetic_example、run_id以SYNTHETIC开头；汇总脚本必须拒绝纳入实测表。样本计时：process=init+warmup+prewindow+solver+postprocess+finalize；diagnostics与solver_required传输/等待已在solver内，不能再加一次。样本CPU无数值，不伪造加速比。

字段字典是科学语义名称，CSV使用明确单位后缀；metadata字段放manifest，物理输入放physics.json，其他字段对应上述表。模板以长表表达硬件计数器，native_metric_name必须由现场工具回填，不能把语义名称当作现成可用的Nsight metric。

最低实现优先run_manifest/run_summary/stage_timing/step_stats/body_stats/missing_metrics/run_registry。硬件计数器与细分memory/transfer均需采集尝试，不要求所有run开profiler。没有工具的字段填写missing_metrics，不生成看似实测的空报告。


---

> V4补充：逐case配置/频率/场输出以11、12及case_cards为准。先绑定真实时刻并执行13的输出preflight。

# 发给4090服务器Cursor的增量任务

读取00、04、06、07和parameter_dictionary；06/07覆盖旧冲突。先盘点已完成记录，不重跑已满足新口径的任务。V3 planned_runs是调整分工后的计划，不证明任务已运行；保留所有旧run目录与ID，registry添加旧新关联。

1. 在当前论文worktree内检查实际源与同步路径；独立build保存CPU FP32/FP64与GPU FP32。
2. 实现metadata、计时账本与缺失状态，保留V2全部物理字段；CSV模板按本包写出，不能用虚构样本填正式结果。
3. 修改调度owner：4090承担原3090 Ti主计划；本机CPU做A精度及CPU64主基线。其他GPU清单用3090 Ti替代原次级4090，避免4090共同点重复排队。主group扫描只在4090。
4. A组每例选代表档输出5—10组VTP；CSV先导确定50—100点窗口及事件加密。B/C代表展示序列也由4090生成，正式性能重复关闭大输出。
5. 短测检查总时间、init/solver/output、各级步数、阶段calls、内存；检查solver必需传输未扣除，等待未重复相加。旧阶段粗计时合格可复用，不能凭估算拆kernel。
6. B2/B3代表短窗做详细profile和计时/监测开关对照，保留工具原始报告。无计数器权限不申请购买或改系统；记录权限错误和缺口。
7. 由原始数据推导吞吐率、内存每粒子、SD/CV、能量（覆盖有效时）。同窗口、同算法、同诊断才能配对。
8. 输出coverage_report.csv：每个metric_id的implemented/measured/missing/not_applicable、run_id、证据。基础必需项缺失先修；其他缺口逐项报告。三次benchmark通过后汇总，不因本次补字段重跑全部物理展示。

既有工程代码还未由本包修改；实际接口与命令必须现场实现和短测确认，不得声称模板已能采集所有硬件指标。


---

# A1 二维Poiseuille：一次准备完整采集

## 计算与输入

按冻结几何和Re计算通道流，验证速度剖面、流量和稳态；保持增删粒子及边界规则一致。

必须保存输入：通道长高；各body dp/h；rho、mu、声速、Re定义；入口速度/启动函数、出口压力；初态、边界及修正、CFL/dt；剖面截面和探针坐标。

## 每种配置与运行数量

A组不安排正式性能三重复；每档CPU FP64/CPU FP32/GPU FP32各一条完整验证轨迹。

仅4090 GPU FP32的L2验证轨迹附带VTP；L1/L3、CPU与可选FP64不重复场输出。

具体设备/档位/重复见case_execution_matrix.csv及planned_runs.csv。相同配置只提交一个任务，runner内部完成全部必要轨迹；不是把统计上需要的三次重复减为一次。

## 物理量及频率

| 类别 | 必收内容 | 规则 |
|---|---|---|
| 曲线/探针 | 中心速度、流量、压降、进出口累计质量、活跃粒子数 | uniform100，具体定义见12；正式前生成绝对时刻JSON |
| 诊断/收支 | 质量收支、最大速度/密度偏差、稳态残差；初末N及增删事件 | 验证/展示与主曲线公共时刻；benchmark低成本51点；高成本邻居/质量只起中末3点 |
| 最终精度结果 | 最终u(y)、流量与解析值的L2/Linf；CPU FP64/FP32/GPU FP32差；三档误差 | 结束一次或选定比较窗结束一次；保留原始曲线/剖面 |
| VTP字段 | Position,ParticleID,Velocity,Pressure,Density,BodyID | transient5；只在指定代表轨迹，最多10个目标时刻 |
| 输入/环境/构建 | 公共manifest、physics、hash、实际精度/group/CPU线程 | 启动一次；动态配置变化另记事件 |
| 性能统计 | 总体/阶段时间、calls、各级步数/dt、更新量、内存、状态 | 每次调用内存累计，结束汇总；不每步写CSV |
| 设备监测 | 显存、RSS、功率/温度/频率/降频 | 默认1s墙钟，短任务说明覆盖；性能累计日志刷新默认关闭，可选30s |

## 终点及放行

按冻结的稳态判据达到要求；先导冻结T，正式三后端用同T并检查末态是否满足稳态。

最终剖面按相同空间采样网格插值输出一次；空间点数不受时间100点上限约束。若终止仍未稳态标未达标，不把最后一帧称稳态。

运行前必须列出实际数值：dp/N、终点或迭代、性能窗口、公共采样绝对时刻、VTP绝对时刻、真实字段名和测点坐标/单位。绑定脚本只生成时间表，不改求解器；Cursor必须把当前代码writer/observer接到这些规则。执行前打印预计CSV点数、每个body VTP文件数和总存储估计。

运行结束核对：预定输出已生成或说明终止原因，requested_time/actual_time俱全；没有以0代替缺失；窗口外准备/输出未混入主性能；峰值/相位精度检查通过。未满足条件保留失败结果，不能自动改窗口或物理参数冒充同配置。


---

# A2 二维梁振动：一次准备完整采集

## 计算与输入

固定夹持、材料和激励，计算自由振动及变形；三档分辨率核对频率、振幅、能量。

必须保存输入：梁长厚、夹持段、dp及厚度层数；rho_s、E、nu、本构、阻尼；初始位移/速度函数、dt规则、尾端位置。

## 每种配置与运行数量

A组不安排正式性能三重复；每档CPU FP64/CPU FP32/GPU FP32各一条完整验证轨迹。

仅4090 GPU FP32的L2验证轨迹附带VTP；L1/L3、CPU与可选FP64不重复场输出。

具体设备/档位/重复见case_execution_matrix.csv及planned_runs.csv。相同配置只提交一个任务，runner内部完成全部必要轨迹；不是把统计上需要的三次重复减为一次。

## 物理量及频率

| 类别 | 必收内容 | 规则 |
|---|---|---|
| 曲线/探针 | 尾端x/y位移及速度、动能、应变能 | cycles100，具体定义见12；正式前生成绝对时刻JSON |
| 诊断/收支 | 实际固体步数、dt统计、能量衰减/数值稳定性、固定区约束 | 验证/展示与主曲线公共时刻；benchmark低成本51点；高成本邻居/质量只起中末3点 |
| 最终精度结果 | 同一选定4周期窗口的主频、各周期幅值、均值、相位；独立参考误差与CPU/GPU差 | 结束一次或选定比较窗结束一次；保留原始曲线/剖面 |
| VTP字段 | Position,ParticleID,Displacement,Velocity,BodyID,stress scalar if implemented and defined | cycle8；只在指定代表轨迹，最多10个目标时刻 |
| 输入/环境/构建 | 公共manifest、physics、hash、实际精度/group/CPU线程 | 启动一次；动态配置变化另记事件 |
| 性能统计 | 总体/阶段时间、calls、各级步数/dt、更新量、内存、状态 | 每次调用内存累计，结束汇总；不每步写CSV |
| 设备监测 | 显存、RSS、功率/温度/频率/降频 | 默认1s墙钟，短任务说明覆盖；性能累计日志刷新默认关闭，可选30s |

## 终点及放行

先导冻结P_ref和观测起点S；至少计算到S+4P_ref；衰减振动使用同一绝对时间窗，不强求不衰减稳态。

P_ref来自已有参考或CPU FP64先导，不能每个GPU自行估计P再重定义采样时刻。可选GPU FP64仅L2，不能混入FP32性能。

运行前必须列出实际数值：dp/N、终点或迭代、性能窗口、公共采样绝对时刻、VTP绝对时刻、真实字段名和测点坐标/单位。绑定脚本只生成时间表，不改求解器；Cursor必须把当前代码writer/observer接到这些规则。执行前打印预计CSV点数、每个body VTP文件数和总存储估计。

运行结束核对：预定输出已生成或说明终止原因，requested_time/actual_time俱全；没有以0代替缺失；窗口外准备/输出未混入主性能；峰值/相位精度检查通过。未满足条件保留失败结果，不能自动改窗口或物理参数冒充同配置。


---

# A3 窗框D4或D7传热：一次准备完整采集

## 计算与输入

只选已冻结D4或D7，保持多材料导热及Robin边界，验证温度分布、热流和稳态收敛。

必须保存输入：几何及材料区；每区k、rho*cp或伪时间定义；室内外温度和h、局部减弱换热；初温；dp/h、参考COMSOL配置、测点及稳态阈值。

## 每种配置与运行数量

A组不安排正式性能三重复；每档CPU FP64/CPU FP32/GPU FP32各一条完整验证轨迹。

仅4090 GPU FP32的L2验证轨迹附带VTP；L1/L3、CPU与可选FP64不重复场输出。

具体设备/档位/重复见case_execution_matrix.csv及planned_runs.csv。相同配置只提交一个任务，runner内部完成全部必要轨迹；不是把统计上需要的三次重复减为一次。

## 物理量及频率

| 类别 | 必收内容 | 规则 |
|---|---|---|
| 曲线/探针 | 全部固定温度测点、室内侧总热流、室外侧总热流、温度残差 | uniform100，具体定义见12；正式前生成绝对时刻JSON |
| 诊断/收支 | 热收支、温度范围、扩散迭代计数/dt；材料区粒子数 | 验证/展示与主曲线公共时刻；benchmark低成本51点；高成本邻居/质量只起中末3点 |
| 最终精度结果 | 最终温度剖面/测点、总热流与COMSOL误差；CPU/GPU差；三档收敛 | 结束一次或选定比较窗结束一次；保留原始曲线/剖面 |
| VTP字段 | Position,ParticleID,Temperature,MaterialRegionID,conductivity if actually stored; heat-flux vector only if validated | transient5；只在指定代表轨迹，最多10个目标时刻 |
| 输入/环境/构建 | 公共manifest、physics、hash、实际精度/group/CPU线程 | 启动一次；动态配置变化另记事件 |
| 性能统计 | 总体/阶段时间、calls、各级步数/dt、更新量、内存、状态 | 每次调用内存累计，结束汇总；不每步写CSV |
| 设备监测 | 显存、RSS、功率/温度/频率/降频 | 默认1s墙钟，短任务说明覆盖；性能累计日志刷新默认关闭，可选30s |

## 终点及放行

先导冻结达到温度残差和热流平衡要求的T或迭代I；正式同一终点检查，不仅沿用旧End_Time。

若是伪时间或无热容的稳态迭代，用迭代轴，禁止把该轴冒充真实秒；最终截面空间数据单独保存一次。

运行前必须列出实际数值：dp/N、终点或迭代、性能窗口、公共采样绝对时刻、VTP绝对时刻、真实字段名和测点坐标/单位。绑定脚本只生成时间表，不改求解器；Cursor必须把当前代码writer/observer接到这些规则。执行前打印预计CSV点数、每个body VTP文件数和总存储估计。

运行结束核对：预定输出已生成或说明终止原因，requested_time/actual_time俱全；没有以0代替缺失；窗口外准备/输出未混入主性能；峰值/相位精度检查通过。未满足条件保留失败结果，不能自动改窗口或物理参数冒充同配置。


---

# A4 二维两相溃坝：一次准备完整采集

## 计算与输入

保持两相物性和界面/边界模型，计算溃坝界面、前沿及压力关键事件。

必须保存输入：槽和水柱几何、各body dp；各相rho、mu、c、EOS；重力、相间模型、表面张力/接触角（启用才填）；CFL、探针与参考时间无量纲定义。

## 每种配置与运行数量

A组不安排正式性能三重复；每档CPU FP64/CPU FP32/GPU FP32各一条完整验证轨迹。

仅4090 GPU FP32的L2验证轨迹附带VTP；L1/L3、CPU与可选FP64不重复场输出。

具体设备/档位/重复见case_execution_matrix.csv及planned_runs.csv。相同配置只提交一个任务，runner内部完成全部必要轨迹；不是把统计上需要的三次重复减为一次。

## 物理量及频率

| 类别 | 必收内容 | 规则 |
|---|---|---|
| 曲线/探针 | 各指定压力测点、水位、前沿；压力峰值和到达时刻 | event100，具体定义见12；正式前生成绝对时刻JSON |
| 诊断/收支 | 各相质量及收支、机械能、最大速度/密度偏差、各级步数 | 验证/展示与主曲线公共时刻；benchmark低成本51点；高成本邻居/质量只起中末3点 |
| 最终精度结果 | 参考界面/水位/前沿/冲击峰值与到达时间；CPU/GPU及三档对照 | 结束一次或选定比较窗结束一次；保留原始曲线/剖面 |
| VTP字段 | Position,ParticleID,Velocity,Pressure,Density,PhaseID or separate bodies | event8；只在指定代表轨迹，最多10个目标时刻 |
| 输入/环境/构建 | 公共manifest、physics、hash、实际精度/group/CPU线程 | 启动一次；动态配置变化另记事件 |
| 性能统计 | 总体/阶段时间、calls、各级步数/dt、更新量、内存、状态 | 每次调用内存累计，结束汇总；不每步写CSV |
| 设备监测 | 显存、RSS、功率/温度/频率/降频 | 默认1s墙钟，短任务说明覆盖；性能累计日志刷新默认关闭，可选30s |

## 终点及放行

冻结[0,T]与冲击区间[a,b]，必须覆盖首个论文比较冲击事件及其后响应。

全程100个基础CSV时刻，冲击[a,b]额外21个目标点并去重；只在该窗口用原有合法探针调用记录更密事件，必要时增加，不把121视为硬上限。峰值基于足够密的原始探针，不取稀疏VTP峰值。

运行前必须列出实际数值：dp/N、终点或迭代、性能窗口、公共采样绝对时刻、VTP绝对时刻、真实字段名和测点坐标/单位。绑定脚本只生成时间表，不改求解器；Cursor必须把当前代码writer/observer接到这些规则。执行前打印预计CSV点数、每个body VTP文件数和总存储估计。

运行结束核对：预定输出已生成或说明终止原因，requested_time/actual_time俱全；没有以0代替缺失；窗口外准备/输出未混入主性能；峰值/相位精度检查通过。未满足条件保留失败结果，不能自动改窗口或物理参数冒充同配置。


---

# A5 圆柱＋柔性尾板FSI2：一次准备完整采集

## 计算与输入

标准尾板双向FSI；流体、结构子步、压力/黏性载荷和夹持约束全部开启。

必须保存输入：通道/圆柱/尾板几何；流固dp比及真实尾板层数；流体rho、mu、c、Re和入口函数；固体rho、E、nu、本构/阻尼；耦合子步、reload/初态。

## 每种配置与运行数量

A组不安排正式性能三重复；每档CPU FP64/CPU FP32/GPU FP32各一条完整验证轨迹。

仅4090 GPU FP32的L2验证轨迹附带VTP；L1/L3、CPU与可选FP64不重复场输出。

具体设备/档位/重复见case_execution_matrix.csv及planned_runs.csv。相同配置只提交一个任务，runner内部完成全部必要轨迹；不是把统计上需要的三次重复减为一次。

## 物理量及频率

| 类别 | 必收内容 | 规则 |
|---|---|---|
| 曲线/探针 | 尾端x/y位移和速度、压力与黏性载荷；稳定窗口均值/幅频相位 | cycles100，具体定义见12；正式前生成绝对时刻JSON |
| 诊断/收支 | 流固各级步数/dt、子步保护、质量/能量适用摘要、固定区约束；启动阶段51个低成本检查点 | 验证/展示与主曲线公共时刻；benchmark低成本51点；高成本邻居/质量只起中末3点 |
| 最终精度结果 | 标准参考振幅/频率/均值；独立参考误差、CPU/GPU相位与幅频差；三档流固同比细化 | 结束一次或选定比较窗结束一次；保留原始曲线/剖面 |
| VTP字段 | Fluid:Position,ParticleID,Velocity,Pressure,Density; Solid:Position,ParticleID,Displacement,Velocity,defined stress scalar | cycle8；只在指定代表轨迹，最多10个目标时刻 |
| 输入/环境/构建 | 公共manifest、physics、hash、实际精度/group/CPU线程 | 启动一次；动态配置变化另记事件 |
| 性能统计 | 总体/阶段时间、calls、各级步数/dt、更新量、内存、状态 | 每次调用内存累计，结束汇总；不每步写CSV |
| 设备监测 | 显存、RSS、功率/温度/频率/降频 | 默认1s墙钟，短任务说明覆盖；性能累计日志刷新默认关闭，可选30s |

## 终点及放行

先导确认振动建立，冻结观测起点S及P_ref，运行到S+4P_ref；未建立则报告失败/窗口不足。

稳定性判断采用相邻周期幅值/频率变化和预先登记阈值，不能每个后端挑最好的一段。流固必要载荷每物理步正常计算，低频仅指额外输出。

运行前必须列出实际数值：dp/N、终点或迭代、性能窗口、公共采样绝对时刻、VTP绝对时刻、真实字段名和测点坐标/单位。绑定脚本只生成时间表，不改求解器；Cursor必须把当前代码writer/observer接到这些规则。执行前打印预计CSV点数、每个body VTP文件数和总存储估计。

运行结束核对：预定输出已生成或说明终止原因，requested_time/actual_time俱全；没有以0代替缺失；窗口外准备/输出未混入主性能；峰值/相位精度检查通过。未满足条件保留失败结果，不能自动改窗口或物理参数冒充同配置。


---

# B1 三维复杂几何单分辨率粒子生成/松弛：一次准备完整采集

## 计算与输入

几何和level-set预处理、粒子生成、初始邻域、固定迭代松弛；另记录达到同质量目标的时间。

必须保存输入：几何hash/坐标/缩放、体填充/壳层语义；单分辨率dp、level-set网格；随机种子/初始粒子、松弛规则、固定I及质量目标。

## 每种配置与运行数量

各正式性能配置3次重复；VTP关闭，最低诊断51点（B1按迭代100点）；代表showcase一条，已有合格轨迹可复用。

仅4090一档代表规模输出VTP；B组优先L3，C组COMMON；不在group或其他设备重复输出。

具体设备/档位/重复见case_execution_matrix.csv及planned_runs.csv。相同配置只提交一个任务，runner内部完成全部必要轨迹；不是把统计上需要的三次重复减为一次。

## 物理量及频率

| 类别 | 必收内容 | 规则 |
|---|---|---|
| 曲线/探针 | 松弛残差；若已有低成本则位移/伪速度摘要 | iterations100，具体定义见12；正式前生成绝对时刻JSON |
| 诊断/收支 | 初始、中点、终点粒子数、表面距离误差/最近邻分布等较昂贵质量统计；质量目标首次达到迭代/时间 | 验证/展示与主曲线公共时刻；benchmark低成本51点；高成本邻居/质量只起中末3点 |
| 最终精度结果 | 固定迭代结束质量及同质量耗时；不同设备相同几何/初态/停止规则，不因提前停止制造加速 | 结束一次或选定比较窗结束一次；保留原始曲线/剖面 |
| VTP字段 | Position,ParticleID,BodyID,SurfaceFlag,relaxation residual if actually stored | iterations8；只在指定代表轨迹，最多10个目标时刻 |
| 输入/环境/构建 | 公共manifest、physics、hash、实际精度/group/CPU线程 | 启动一次；动态配置变化另记事件 |
| 性能统计 | 总体/阶段时间、calls、各级步数/dt、更新量、内存、状态 | 每次调用内存累计，结束汇总；不每步写CSV |
| 设备监测 | 显存、RSS、功率/温度/频率/降频 | 默认1s墙钟，短任务说明覆盖；性能累计日志刷新默认关闭，可选30s |

## 终点及放行

冻结总I；1000仅为原源码起点，先导后确定；各设备相同I并保留质量达标状态。

固定迭代主计时默认不中途因达标停止；同质量耗时作为附加结果。较昂贵质量统计单独计时；benchmark如计算它必须CPU/GPU相同，或在窗外执行。

运行前必须列出实际数值：dp/N、终点或迭代、性能窗口、公共采样绝对时刻、VTP绝对时刻、真实字段名和测点坐标/单位。绑定脚本只生成时间表，不改求解器；Cursor必须把当前代码writer/observer接到这些规则。执行前打印预计CSV点数、每个body VTP文件数和总存储估计。

运行结束核对：预定输出已生成或说明终止原因，requested_time/actual_time俱全；没有以0代替缺失；窗口外准备/输出未混入主性能；峰值/相位精度检查通过。未满足条件保留失败结果，不能自动改窗口或物理参数冒充同配置。


---

# B2 三维溃坝性能基准：一次准备完整采集

## 计算与输入

完整动态流体计算，含cell、排序、inner/contact关系、规约和物理积分；五档规模及共同规模跨设备。

必须保存输入：槽/水柱尺寸、rho、g、c、核与修正、CFL/dt、dp、排序/关系更新政策；初态与性能窗[t_a,t_b]。

## 每种配置与运行数量

各正式性能配置3次重复；VTP关闭，最低诊断51点（B1按迭代100点）；代表showcase一条，已有合格轨迹可复用。

仅4090一档代表规模输出VTP；B组优先L3，C组COMMON；不在group或其他设备重复输出。

具体设备/档位/重复见case_execution_matrix.csv及planned_runs.csv。相同配置只提交一个任务，runner内部完成全部必要轨迹；不是把统计上需要的三次重复减为一次。

## 物理量及频率

| 类别 | 必收内容 | 规则 |
|---|---|---|
| 曲线/探针 | 冻结压力探针、水位等最低摘要；展示轨迹可保存完整参考曲线 | window51，具体定义见12；正式前生成绝对时刻JSON |
| 诊断/收支 | 质量、最大速度/密度偏差、实际声学/对流步数、稀疏邻居/cell占用 | 验证/展示与主曲线公共时刻；benchmark低成本51点；高成本邻居/质量只起中末3点 |
| 最终精度结果 | 跨端物理一致性摘要与实际工作量；不将B组扩成第二套全面物理验证 | 结束一次或选定比较窗结束一次；保留原始曲线/剖面 |
| VTP字段 | Position,ParticleID,Velocity,Pressure,Density,BodyID | evolution8；只在指定代表轨迹，最多10个目标时刻 |
| 输入/环境/构建 | 公共manifest、physics、hash、实际精度/group/CPU线程 | 启动一次；动态配置变化另记事件 |
| 性能统计 | 总体/阶段时间、calls、各级步数/dt、更新量、内存、状态 | 每次调用内存累计，结束汇总；不每步写CSV |
| 设备监测 | 显存、RSS、功率/温度/频率/降频 | 默认1s墙钟，短任务说明覆盖；性能累计日志刷新默认关闭，可选30s |

## 终点及放行

冻结代表性能窗W；展示轨迹覆盖预选场时刻；不自动采用源码20s。

benchmark最低诊断51点；showcase曲线100点，有论文要展示冲击压力时加局部事件采样。profile只在代表短窗，五档不全开profiler。

运行前必须列出实际数值：dp/N、终点或迭代、性能窗口、公共采样绝对时刻、VTP绝对时刻、真实字段名和测点坐标/单位。绑定脚本只生成时间表，不改求解器；Cursor必须把当前代码writer/observer接到这些规则。执行前打印预计CSV点数、每个body VTP文件数和总存储估计。

运行结束核对：预定输出已生成或说明终止原因，requested_time/actual_time俱全；没有以0代替缺失；窗口外准备/输出未混入主性能；峰值/相位精度检查通过。未满足条件保留失败结果，不能自动改窗口或物理参数冒充同配置。


---

# B3 三维扭转柱性能基准：一次准备完整采集

## 计算与输入

固定材料/激励/约束，完整固体积分、阻尼及真实需要的关系更新；五档与共同规模硬件比较。

必须保存输入：柱几何、rho、E、nu、本构；初始角速度分布、夹持区、阻尼、dp、dt、参考构型关系和重建政策。

## 每种配置与运行数量

各正式性能配置3次重复；VTP关闭，最低诊断51点（B1按迭代100点）；代表showcase一条，已有合格轨迹可复用。

仅4090一档代表规模输出VTP；B组优先L3，C组COMMON；不在group或其他设备重复输出。

具体设备/档位/重复见case_execution_matrix.csv及planned_runs.csv。相同配置只提交一个任务，runner内部完成全部必要轨迹；不是把统计上需要的三次重复减为一次。

## 物理量及频率

| 类别 | 必收内容 | 规则 |
|---|---|---|
| 曲线/探针 | 端部位移/速度、动能/应变能 | window51，具体定义见12；正式前生成绝对时刻JSON |
| 诊断/收支 | 实际固体步数/dt、约束、参考关系是否重建及调用次数 | 验证/展示与主曲线公共时刻；benchmark低成本51点；高成本邻居/质量只起中末3点 |
| 最终精度结果 | 端部运动/能量/代表变形的跨端一致性；不虚构不存在的动态邻域成本 | 结束一次或选定比较窗结束一次；保留原始曲线/剖面 |
| VTP字段 | Position,ParticleID,Displacement,Velocity,BodyID,defined stress scalar | cycle8；只在指定代表轨迹，最多10个目标时刻 |
| 输入/环境/构建 | 公共manifest、physics、hash、实际精度/group/CPU线程 | 启动一次；动态配置变化另记事件 |
| 性能统计 | 总体/阶段时间、calls、各级步数/dt、更新量、内存、状态 | 每次调用内存累计，结束汇总；不每步写CSV |
| 设备监测 | 显存、RSS、功率/温度/频率/降频 | 默认1s墙钟，短任务说明覆盖；性能累计日志刷新默认关闭，可选30s |

## 终点及放行

性能窗按先导冻结；展示另冻结S/P_ref；周期不可定义时采用8个指定演化时刻。

benchmark最低51点；showcase使用选定4周期100点或全展示窗100点。最大变形应靠先导相位定位，不能保证任意最终帧最大。

运行前必须列出实际数值：dp/N、终点或迭代、性能窗口、公共采样绝对时刻、VTP绝对时刻、真实字段名和测点坐标/单位。绑定脚本只生成时间表，不改求解器；Cursor必须把当前代码writer/observer接到这些规则。执行前打印预计CSV点数、每个body VTP文件数和总存储估计。

运行结束核对：预定输出已生成或说明终止原因，requested_time/actual_time俱全；没有以0代替缺失；窗口外准备/输出未混入主性能；峰值/相位精度检查通过。未满足条件保留失败结果，不能自动改窗口或物理参数冒充同配置。


---

# C1 工业齿轮箱：一次准备完整采集

## 计算与输入

成熟冻结工况的流体、运动、黏性生热、热扩散和热边界；不计算contact factor/覆盖率专用诊断。

必须保存输入：各CAD/粒子hash、每body dp、油量/液位；油rho、mu、c、k、cp和温度模型；固体热物性；各轴运动；初温、热源、边界；COMMON/性能窗。

## 每种配置与运行数量

各正式性能配置3次重复；VTP关闭，最低诊断51点（B1按迭代100点）；代表showcase一条，已有合格轨迹可复用。

仅4090一档代表规模输出VTP；B组优先L3，C组COMMON；不在group或其他设备重复输出。

具体设备/档位/重复见case_execution_matrix.csv及planned_runs.csv。相同配置只提交一个任务，runner内部完成全部必要轨迹；不是把统计上需要的三次重复减为一次。

## 物理量及频率

| 类别 | 必收内容 | 规则 |
|---|---|---|
| 曲线/探针 | 各轴扭矩、由omega得到的功率；油和各齿轮/壁温摘要 | industrial51，具体定义见12；正式前生成绝对时刻JSON |
| 诊断/收支 | 油质量、各级步数/dt、现有低成本热收支；已有每步载荷可累计均值但不新增昂贵每步诊断 | 验证/展示与主曲线公共时刻；benchmark低成本51点；高成本邻居/质量只起中末3点 |
| 最终精度结果 | 共同窗口CPU/GPU最低物理一致性，短性能与长热展示分开注明，不新增全工况物理研究 | 结束一次或选定比较窗结束一次；保留原始曲线/剖面 |
| VTP字段 | Oil:Position,ParticleID,Velocity,Pressure,Temperature; Gears/Wall:Position,BodyID,Temperature | industrial8；只在指定代表轨迹，最多10个目标时刻 |
| 输入/环境/构建 | 公共manifest、physics、hash、实际精度/group/CPU线程 | 启动一次；动态配置变化另记事件 |
| 性能统计 | 总体/阶段时间、calls、各级步数/dt、更新量、内存、状态 | 每次调用内存累计，结束汇总；不每步写CSV |
| 设备监测 | 显存、RSS、功率/温度/频率/降频 | 默认1s墙钟，短任务说明覆盖；性能累计日志刷新默认关闭，可选30s |

## 终点及放行

性能窗覆盖代表运动/热操作；展示窗可更长，温度展示终点按实际可用轨迹冻结；2.1s仅旧论文参考。

展示CSV先选代表4个最快轴转动周期100点；长热过程另100点。均扭矩优先用物理所需载荷累计平均，不声称100点能解析齿啮合高频峰值。热过程若尚无显著升温如实标注，不能延长短性能时间后混比。

运行前必须列出实际数值：dp/N、终点或迭代、性能窗口、公共采样绝对时刻、VTP绝对时刻、真实字段名和测点坐标/单位。绑定脚本只生成时间表，不改求解器；Cursor必须把当前代码writer/observer接到这些规则。执行前打印预计CSV点数、每个body VTP文件数和总存储估计。

运行结束核对：预定输出已生成或说明终止原因，requested_time/actual_time俱全；没有以0代替缺失；窗口外准备/输出未混入主性能；峰值/相位精度检查通过。未满足条件保留失败结果，不能自动改窗口或物理参数冒充同配置。


---

# C2 工业搅拌：一次准备完整采集

## 计算与输入

冻结成熟单/两相版本和桨叶运动，完整移动边界/接触及流体积分；不为论文添加新混合模型。

必须保存输入：容器/叶轮hash、坐标/旋转轴；液位、各相物性；omega/启动函数；各body dp、运动/邻域政策和性能窗。

## 每种配置与运行数量

各正式性能配置3次重复；VTP关闭，最低诊断51点（B1按迭代100点）；代表showcase一条，已有合格轨迹可复用。

仅4090一档代表规模输出VTP；B组优先L3，C组COMMON；不在group或其他设备重复输出。

具体设备/档位/重复见case_execution_matrix.csv及planned_runs.csv。相同配置只提交一个任务，runner内部完成全部必要轨迹；不是把统计上需要的三次重复减为一次。

## 物理量及频率

| 类别 | 必收内容 | 规则 |
|---|---|---|
| 曲线/探针 | 桨叶扭矩、少量固定速度探针 | industrial51，具体定义见12；正式前生成绝对时刻JSON |
| 诊断/收支 | 各相质量、实际各级步数；自由面或气含率仅有可靠现成低成本实现时启用 | 验证/展示与主曲线公共时刻；benchmark低成本51点；高成本邻居/质量只起中末3点 |
| 最终精度结果 | 共同规模跨端物理一致性；不要求混合时间或示踪剂新研究 | 结束一次或选定比较窗结束一次；保留原始曲线/剖面 |
| VTP字段 | Position,ParticleID,Velocity,Pressure,Density,PhaseID; blade geometry position | industrial8；只在指定代表轨迹，最多10个目标时刻 |
| 输入/环境/构建 | 公共manifest、physics、hash、实际精度/group/CPU线程 | 启动一次；动态配置变化另记事件 |
| 性能统计 | 总体/阶段时间、calls、各级步数/dt、更新量、内存、状态 | 每次调用内存累计，结束汇总；不每步写CSV |
| 设备监测 | 显存、RSS、功率/温度/频率/降频 | 默认1s墙钟，短任务说明覆盖；性能累计日志刷新默认关闭，可选30s |

## 终点及放行

性能窗在代表旋转/界面段，展示冻结成熟转动状态S/P_ref。

showcase曲线选4转100点；桨叶必要力不能降频，额外写出可降频。自由面仍变化时称代表状态，不称静态稳态。

运行前必须列出实际数值：dp/N、终点或迭代、性能窗口、公共采样绝对时刻、VTP绝对时刻、真实字段名和测点坐标/单位。绑定脚本只生成时间表，不改求解器；Cursor必须把当前代码writer/observer接到这些规则。执行前打印预计CSV点数、每个body VTP文件数和总存储估计。

运行结束核对：预定输出已生成或说明终止原因，requested_time/actual_time俱全；没有以0代替缺失；窗口外准备/输出未混入主性能；峰值/相位精度检查通过。未满足条件保留失败结果，不能自动改窗口或物理参数冒充同配置。


---

# C3 两相储箱换热与晃荡：一次准备完整采集

## 计算与输入

冻结两相流热、相间换热和晃荡运动；不增加相变/EM；性能窗保持全部热操作开启。

必须保存输入：储箱/充液率/各body dp；两相rho、mu、c、k、cp及EOS、相间热模型；初温、热边界；晃荡幅频方向和完整函数、COMMON/窗口。

## 每种配置与运行数量

各正式性能配置3次重复；VTP关闭，最低诊断51点（B1按迭代100点）；代表showcase一条，已有合格轨迹可复用。

仅4090一档代表规模输出VTP；B组优先L3，C组COMMON；不在group或其他设备重复输出。

具体设备/档位/重复见case_execution_matrix.csv及planned_runs.csv。相同配置只提交一个任务，runner内部完成全部必要轨迹；不是把统计上需要的三次重复减为一次。

## 物理量及频率

| 类别 | 必收内容 | 规则 |
|---|---|---|
| 曲线/探针 | 指定压力/水位、两相平均温度 | industrial51，具体定义见12；正式前生成绝对时刻JSON |
| 诊断/收支 | 两相质量、适用现有热量摘要、各级步数/dt | 验证/展示与主曲线公共时刻；benchmark低成本51点；高成本邻居/质量只起中末3点 |
| 最终精度结果 | 共同规模跨端最低流热一致性；局部冲击和长程热曲线按展示用途记录 | 结束一次或选定比较窗结束一次；保留原始曲线/剖面 |
| VTP字段 | Position,ParticleID,Velocity,Pressure,Temperature,PhaseID; wall temperature if solved | industrial8；只在指定代表轨迹，最多10个目标时刻 |
| 输入/环境/构建 | 公共manifest、physics、hash、实际精度/group/CPU线程 | 启动一次；动态配置变化另记事件 |
| 性能统计 | 总体/阶段时间、calls、各级步数/dt、更新量、内存、状态 | 每次调用内存累计，结束汇总；不每步写CSV |
| 设备监测 | 显存、RSS、功率/温度/频率/降频 | 默认1s墙钟，短任务说明覆盖；性能累计日志刷新默认关闭，可选30s |

## 终点及放行

性能窗覆盖代表晃荡相位；showcase冻结4周期流动窗和可用热展示终点。

晃荡曲线4周期100点；长热曲线另100点；若研究冲击峰值需[a,b]加密。8组场中保留至少一个长热末态，若该时刻实际未运行不得补造。

运行前必须列出实际数值：dp/N、终点或迭代、性能窗口、公共采样绝对时刻、VTP绝对时刻、真实字段名和测点坐标/单位。绑定脚本只生成时间表，不改求解器；Cursor必须把当前代码writer/observer接到这些规则。执行前打印预计CSV点数、每个body VTP文件数和总存储估计。

运行结束核对：预定输出已生成或说明终止原因，requested_time/actual_time俱全；没有以0代替缺失；窗口外准备/输出未混入主性能；峰值/相位精度检查通过。未满足条件保留失败结果，不能自动改窗口或物理参数冒充同配置。
