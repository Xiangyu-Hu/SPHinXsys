> V4补充：逐case配置/频率/场输出以11、12及case_cards为准。先绑定真实时刻并执行13的输出preflight。

> V3（2026-11-03）：主协调端为4090＋64核CPU同一服务器。记录细则以06、07为准；旧文档与之冲突时采用06、07。所有结果仍待现场实测。

# 每个案例的参数、输出、比较用途总表

V物理验证；P精度；R分辨率；G工作组；H硬件；B阶段瓶颈；C条件一致。以下每行“输入”都要记录实际值、单位和来源，不能只抄字段名。“输出”要在粗档短测中确认真实生成。所有case还需04里的公共元数据。

## 1. A组：物理与精度验证

| 案例 | 要记录的输入 | 要记录的输出 | 对应比较 |
|---|---|---|---|
| A1 Poiseuille | 通道长高、dp/h、rho/mu/c、Re定义、入口速度及启动函数、出口压力、初态、边界/修正、dt/CFL、探针坐标 | u(y)、中心u(t)、Q(t)、压降、进出口累计质量、N(t)、实际步数/时间 | 解析剖面与流量V；CPU64/CPU32/GPU32差P；三档误差R；收支/步数C |
| A2 梁振动 | 梁长厚、夹持段、dp/厚度层数、rho/E/nu、本构、初始速度/位移激励、阻尼、dt、探针位置 | 尾端x/y位移和速度、主频、各周期振幅、均值/相位、动能/应变能、实际步数 | 文献/适用理论V；精度P；三档R；能量/步数C |
| A3 窗框D4/D7 | 几何/材料区、各区导热系数、rho*cp或扩散/伪时间定义、室内外温度与Robin系数、局部减弱换热区、初温、dp/h、稳态阈值、COMSOL对应配置与测点 | Phi/温度测点、同截面分布、内外总热流、热收支、稳态残差、扩散迭代数与时间 | 对COMSOL V；CPU64/CPU32/GPU32及可选GPU64 P；材料界面细化R；收敛/迭代C |
| A4 两相溃坝 | 水槽/水柱几何、两相rho/mu/c/EOS、重力、相间模型、表面张力/接触角（如启用）、dp/h、CFL、压力探针及界面采样方式 | 界面帧、水位/前沿、压力p(t)/峰值/到达时间、两相质量、最大速度/密度偏差、机械能、步数 | 文献/实验V；精度P；界面/压力细化R；守恒与步数C |
| A5 圆柱柔性尾板FSI2 | 通道/圆柱/尾板尺寸、流固各dp及比值、实际尾板层数、流体rho/mu/c/Re与入口启动、固体rho/E/nu/本构、夹持、阻尼、流固耦合/子步规则、reload初态 | 尾端x/y位移、均值/振幅/频率/相位、结构载荷（压力/黏性）、代表变形/流场、dt/Dt/dt_s、各类步数与保护触发 | 标准FSI文献V；精度P；流固同比细化R；双向传力/子步C |

A组三版本必须共享模型和初态；GPU64仅A2/A3中档可选。不同编译精度可能导致生成粒子差异，优先离线生成一次并统一载入。保存完整验证数据即可，不要求全套性能细分。

## 2. B组：五档规模、group和硬件

| 案例 | 固定物理/算法输入 | 每档规模参数 | 性能字段 | 质量/一致性输出 | 比较 |
|---|---|---|---|---|---|
| B1 复杂几何level-set/松弛 | 几何hash/坐标/缩放、实体/壳层定义、单分辨率设置、SDF网格/修正、随机种子/初始点、松弛规则与停止标准 | L1—L5的dp、实际N、表面N、level-set节点/块/网格层信息、内存 | 几何/level-set/粒子生成/初始关系/松弛/约束时间；迭代均时、粒子更新率、可信邻居估计率、峰值内存 | 表面距离误差、最近邻分布、松弛残差；固定迭代与达到同质量的迭代/耗时 | 五档R；中档group G；COMMON H；阶段B；质量C |
| B2 3D溃坝 | 水槽/水柱、rho/g/c、核/修正、dt/CFL、排序/关系周期、物理窗口 | 每档dp、流体/壁各N、inner/contact邻居统计、occupied cells/桶占用、reserve | solver/process/init/output时间、各级步均时、MPPS/MNIPS口径、cell/relation/sort/流体/规约阶段、峰值内存 | 质量、压力/水位摘要、最大速度/密度偏差、各级步数及实际终止时间 | R/G/H/B/C |
| B3 3D扭转柱 | 柱几何、rho/E/nu/本构、初始角速度分布、固定区、阻尼、dt/约束、物理窗口 | 每档dp、实际固体N、初始参考邻域数、实际重建次数 | solver/init/output时间、结构步均时、结构更新率、relation/固体积分/阻尼/规约/约束、内存 | 端部运动、能量、代表变形、结构步数、失败状态 | R/G/H/B/C |

P1旧编号本包统一为B1；旧表3D dambreak B1本包改为B2，扭转柱改为B3。脚本与CSV统一使用本包编号，禁止按旧ID混配。

## 3. C组：单一代表规模跨设备

| 案例 | 固定并归档的输入 | 性能重点 | 最低物理诊断（低频） | 不列为任务 |
|---|---|---|---|---|
| C1 齿轮箱 | CAD/粒子hash、每body dp、油量/液位、油rho/mu/c/k/cp、固体热物性、各轴omega/运动、初温、热源/边界、物理窗口 | 总/各级步均时、MPPS/MNIPS估计、基础设施/流体/黏性/热扩散/热源/热边界/运动/必要规约、内存 | 各轴扭矩及功率可由omega计算、油温及齿轮/壁温摘要、油质量、步数；热收支仅保留现有低成本量 | contact factor、覆盖率、齿轮表面分区润湿、完整多工况贡献率研究 |
| C2 搅拌 | 容器/桨叶、成熟单/两相选择、液位、各相物性、omega与启动函数、旋转轴/单位、各body dp、运动/邻域规则、窗口 | 总/阶段时间、吞吐率、移动边界/相间接触、内存、实际步数 | 桨叶扭矩、少量速度探针、各相质量；现有自由面/气含率可选 | 新增示踪剂/混合时间研究、为论文临时升级多相 |
| C3 热晃荡储箱 | 储箱/充液率、两相rho/mu/c/k/cp/EOS、相间热模型、初温、壁/环境热边界、晃荡幅频/方向/完整函数、dp、窗口 | 两相/邻域/排序/热交换扩散/运动/规约、总体与吞吐率、内存 | 少量压力/水位探针、两相平均温度、两相质量、实际步数；现成低成本热量摘要 | 新加相变或EM、完整参数扫频研究 |

三例COMMON一档，跨CPU/GPU完全一致；热模型启用的项必须真正计算。最低诊断用于H/B结果的C核查，不扩成新物理验证章节。力/扭矩若驱动物体运动必须按物理需要计算，不能低频化必要耦合；低频化仅指输出/额外诊断。

## 4. 分辨率与比较对象落地表（由先导填写）

| 案例 | 起点建议 | 正式冻结时必须填写 | 用途 |
|---|---|---|---|
| A1 | DH/dp=20/40/80 | dp、各body N、参考剖面位置/终止判据 | V/P/R |
| A2 | 厚度方向10/20/40层 | 实际层数、dp、固体N、激励/观测周期 | V/P/R |
| A3 | 由最窄材料区确定，不猜数值 | 每档dp、可解析厚度、材料分区N、稳态标准 | V/P/R |
| A4 | 源码尺寸下dp=0.05/0.025/0.0125为起点 | dp、各相/壁N、参考与窗口、CPU成本 | V/P/R |
| A5 | 保持流固dp比、足够尾板层数 | 各body dp/N、真实尾板层数、参考条件 | V/P/R |
| B1/B2/B3 | 初始化定标五档；COMMON优先L3 | 每档dp/N/邻域/显存；共同档ID；窗口 | R/G/H/B |
| C1/C2/C3 | 采用成熟有依据的代表dp | 每body dp/N、共同档、初态/restart、窗口 | H/B/C |

不要求各case粒子数相同。每档细化保持物理几何不变；壳层厚度若随dp变化，明确这是算法边界带而非真实结构几何改变，并避免拿此变化作物理收敛结论。

## 5. 结果表模板

### 精度表
case / spacing / dp_by_body / N_by_body / backend / real_bytes / reference / reference_error_L2 / reference_error_Linf / CPU64_difference / frequency_error / amplitude_error / phase_or_arrival_error / mass_or_heat_balance / status。按case填适用字段，NA必须有理由。

### 总体性能表
case / spacing / dp / N_by_body / platform / host / cores_threads / real_bytes / group / physical_window或relax_iterations / steps_by_level / wall_solver / wall_init / wall_process / mean_step_by_level / MPPS_proxy或module_updates / MNIPS_est / peak_VRAM / peak_RSS / speedup / repetitions_range / status。

### 阶段性能表
case / spacing / platform / stage / calls / wall_s / fraction / matching_CPU_stage_s / speedup / timing_mode。分组和细项分别出表，避免父子重复相加。

### group表
case / spacing / effective_group / wall_solver_median / min / max / phase_times / correctness_difference / support_status / library_scope。默认64和调优结果不能混为同一种跨设备基线。

### 发布前检查
所有表能追溯到run_id和原始文件；不录入估算伪装成实测；没跑完明确pending；旧论文归一化到2.1s的数据不与新版本直接混用。图表只呈现完成的匹配数据，设备不足不外推。
