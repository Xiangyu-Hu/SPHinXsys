from setuptools import setup

setup(
    name="gym_fish",
    version="1.0",
    install_requires=["gymnasium>=0.27.1", "pygame>=2.3.0"],
)
